<?php

namespace App\Livewire;

use App\Helpers\CartManagement;
use App\Livewire\Partials\Navbar;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Models\Page as SeoPage;
use App\Models\RideInquiry;
use App\Models\User;
use Livewire\Attributes\Url;
use Livewire\Component;
use Livewire\WithPagination;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use DateTime;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use App\Models\Vehicle;



class RidesPage extends Component
{
    use WithPagination;
    use LivewireAlert;

   
    #[Url(history: true)]
    public $selected_categories = [];
    
    #[Url(history: true)]
    public $selected_brands = [];

    #[Url(history: true)]
    public $cityFrom ;
    

    #[Url(history: true)]
    public $cityTo ;

    #[Url(history: true)]
    public $nameTo ;

    #[Url(history: true)]
    public $tab = false ;

    #[Url(history: true)]
    public $days ;

    #[Url(history: true)]
    public $nameFrom ;

    #[Url(history: true)]
    public $date ;

 

    #[Url(history: true)]
    public $dateto ;

    #[Url(history: true)]
    public $plan ;

    #[Url(history: true)]
    public $cars ;

   

    public $query;

    #[Url(history: true)]
    public $price_range = 30000;

   

    #[Url]
    public $sort = 'price';

    #[Url(history: true)]
    public $km ;

    #[Url(history: true)]
    public $kmValue ;

    #[Url(history: true)]
    public $time ;

    #[Url(history: true)]
    public $endTime ;

    #[Url(history: true)]
    public $timeValue ;

    public $query2 = null;
    public $brandsData = [];

    // Edit Query Popup Properties
    public $showEditModal = false;
    public $edit_ride_type = 'one_way';
    public $isLoading = false;
    public $edit_query_search = '';
    public $edit_query2_search = '';
    public $edit_queryLocal = '';
    public $edit_querySelfDrive = '';
    public $edit_queryFrom_search = '';
    public $edit_queryTo_search = '';
    public $edit_date = '';
    public $edit_dateto = '';
    public $edit_time = '';
    public $edit_endTime = '';
    public $edit_plan = '4 Hour / 40 Km';
    public $edit_cars = 1;
    public $edit_days = '';
    public $edit_km = '';
    public $edit_kmValue = '';
    public $edit_timeValue = '';
    
    // Auto-complete data for popup
    public $edit_cities_from = [];
    public $edit_cities_to = [];
    public $edit_dataFrom = [];
    public $edit_dataTo = [];
    
    // City IDs for edit modal
    public $edit_cityFrom_id = null;
    public $edit_cityTo_id = null;
    
    // Fare unlock / OTP lead gate
    public bool $showOtpModal = false;
    public bool $fareUnlocked = false;
    public string $otpStage = 'mobile';
    public string $mobileNumber = '';
    public string $otpCode = '';
    public ?string $otpError = null;
    public int $otpResendSeconds = 0;
    public ?string $pendingBookingAction = null;
    public mixed $pendingBookingPayload = null;

    public string $apiKey = '';

    public function mount(): void
    {
        $this->apiKey = (string) config('services.google_maps.key', env('GOOGLE_MAPS_API_KEY', ''));
        $this->fareUnlocked = (bool) session('rides_fare_unlocked', false) || Auth::check();
        $this->mobileNumber = (string) session('rides_verified_mobile', '');
    }

    

    

    // add product to cart method

    public function updatedQuery(){
        $this-> query = Product::query()->where('is_active',1);
    }

    public function updatedQuery2($query2): void
    {
        $this->brandsData = $this->searchBrands((string) $query2);
    }


    public function addToCart($product_id){
        if (! $this->fareUnlocked) {
            $this->openFareGate('addToCart', func_get_args()[0] ?? null);
            return;
        }

        $total_count = CartManagement::addItemsToCart($product_id);

        $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

        $this->alert('success', 'Package Added to the cart successfully', [
            'position' => 'center-end',
            'timer' => 3000,
            'toast' => true,
           ]);

        redirect(route('checkout'));
    }

    public function addToCartOneWay($product_id){
        if (! $this->fareUnlocked) {
            $this->openFareGate('addToCartOneWay', func_get_args()[0] ?? null);
            return;
        }

        $total_count = CartManagement::addItemsToCartOneWay($product_id);

        $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

        $this->alert('success', 'Package Added to the cart successfully', [
            'position' => 'center-end',
            'timer' => 3000,
            'toast' => true,
           ]);

        redirect(route('checkout'));
    }

    public function addToCartLocal($product_id){
        if (! $this->fareUnlocked) {
            $this->openFareGate('addToCartLocal', func_get_args()[0] ?? null);
            return;
        }

        $total_count = CartManagement::addItemsToCartLocal($product_id);

        $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

        $this->alert('success', 'Package Added to the cart successfully', [
            'position' => 'center-end',
            'timer' => 3000,
            'toast' => true,
           ]);

        redirect(route('checkout'));
    }

    public function addToCartReturn($cat_id){
        if (! $this->fareUnlocked) {
            $this->openFareGate('addToCartReturn', func_get_args()[0] ?? null);
            return;
        }

        $total_count = CartManagement::addItemsToCartReturn($cat_id);

        $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

        $this->alert('success', 'Package Added to the cart successfully', [
            'position' => 'center-end',
            'timer' => 3000,
            'toast' => true,
           ]);

        redirect(route('checkout'));
    }

    public function addToCartSelfDrive($vehicle_id){
        if (! $this->fareUnlocked) {
            $this->openFareGate('addToCartSelfDrive', func_get_args()[0] ?? null);
            return;
        }

        $total_count = CartManagement::addItemsToCartSelfDrive($vehicle_id);

        $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

        $this->alert('success', 'Package Added to the cart successfully', [
            'position' => 'center-end',
            'timer' => 3000,
            'toast' => true,
           ]);

        redirect(route('checkout'));
    }

    public function openFareGate(?string $action = null, mixed $payload = null): void
    {
        if ($this->fareUnlocked) {
            return;
        }

        $this->pendingBookingAction = $action;
        $this->pendingBookingPayload = $payload;
        $this->showOtpModal = true;
        $this->otpStage = 'mobile';
        $this->otpCode = '';
        $this->otpError = null;
    }

    public function closeOtpModal(): void
    {
        $this->showOtpModal = false;
        $this->otpError = null;
        $this->otpCode = '';
    }

    public function sendFareOtp(): void
    {
        $this->resetErrorBag();
        $this->otpError = null;
        $mobile = preg_replace('/\D+/', '', $this->mobileNumber);
        if (strlen($mobile) === 12 && str_starts_with($mobile, '91')) {
            $mobile = substr($mobile, 2);
        }

        if (! preg_match('/^[6-9]\d{9}$/', $mobile)) {
            $this->addError('mobileNumber', 'Please enter a valid 10 digit mobile number.');
            return;
        }

        $rateKey = "rides:otp:send:{$mobile}:" . request()->ip();
        if (Cache::get($rateKey, 0) >= 3) {
            $this->otpError = 'Too many OTP requests. Please try again after 15 minutes.';
            return;
        }

        $otp = (string) random_int(1000, 9999);
        Cache::put("rides:otp:{$mobile}", [
            'otp_hash' => hash('sha256', $otp),
            'attempts' => 0,
            'created_at' => now()->timestamp,
        ], now()->addMinutes(5));
        Cache::put($rateKey, Cache::get($rateKey, 0) + 1, now()->addMinutes(15));

        $this->mobileNumber = $mobile;
        $this->otpStage = 'otp';
        $this->otpCode = '';
        $this->otpResendSeconds = 30;

        $this->deliverFareOtp($mobile, $otp);
        $this->dispatch('rides-otp-sent', seconds: 30);
    }

    public function resendFareOtp(): void
    {
        $this->sendFareOtp();
    }

    public function verifyFareOtp(): void
    {
        $this->resetErrorBag();
        $this->otpError = null;
        $mobile = preg_replace('/\D+/', '', $this->mobileNumber);
        $otp = preg_replace('/\D+/', '', $this->otpCode);

        if (! preg_match('/^\d{4}$/', $otp)) {
            $this->addError('otpCode', 'Enter the complete 4 digit OTP.');
            return;
        }

        $cacheKey = "rides:otp:{$mobile}";
        $stored = Cache::get($cacheKey);
        if (! is_array($stored)) {
            $this->otpError = 'OTP expired. Please request a new OTP.';
            return;
        }

        $attempts = (int) ($stored['attempts'] ?? 0);
        if ($attempts >= 5) {
            Cache::forget($cacheKey);
            $this->otpError = 'Maximum verification attempts exceeded. Please request a new OTP.';
            return;
        }

        if (! hash_equals((string) ($stored['otp_hash'] ?? ''), hash('sha256', $otp))) {
            $stored['attempts'] = $attempts + 1;
            Cache::put($cacheKey, $stored, now()->addMinutes(5));
            $this->otpError = 'Incorrect OTP. Please try again.';
            return;
        }

        Cache::forget($cacheKey);
        $user = $this->findOrCreateUserForMobile($mobile);
        if ($user) {
            Auth::login($user, true);
        }

        session([
            'rides_fare_unlocked' => true,
            'rides_verified_mobile' => $mobile,
        ]);

        $this->fareUnlocked = true;
        $this->showOtpModal = false;
        $this->otpStage = 'mobile';
        $this->otpCode = '';

        $this->createOrUpdateRideInquiry($mobile, $user?->getKey());
        $this->alert('success', 'Mobile verified. Exact fares are now unlocked.', [
            'position' => 'center-end', 'timer' => 3000, 'toast' => true,
        ]);

        $action = $this->pendingBookingAction;
        $payload = $this->pendingBookingPayload;
        $this->pendingBookingAction = null;
        $this->pendingBookingPayload = null;

        if ($action && method_exists($this, $action)) {
            $this->{$action}($payload);
        }
    }

    private function deliverFareOtp(string $mobile, string $otp): void
    {
        $message = "Your DuraCabs OTP is {$otp}. It is valid for 5 minutes.";
        foreach (['App\\Services\\OtpService', 'App\\Services\\SMSService', 'App\\Services\\SmsService'] as $serviceClass) {
            if (! class_exists($serviceClass)) continue;
            try {
                $service = app($serviceClass);
                foreach (['sendOtp', 'send', 'sendSMS'] as $method) {
                    if (method_exists($service, $method)) {
                        $service->{$method}($mobile, $otp, $message);
                        return;
                    }
                }
            } catch (\Throwable $e) {
                Log::warning('Ride fare OTP provider failed', ['error' => $e->getMessage()]);
            }
        }

        // Local fallback: check storage/logs/laravel.log. Replace with your SMS provider in production.
        Log::info('DuraCabs ride fare OTP', ['mobile' => $mobile, 'otp' => $otp]);
    }

    private function findOrCreateUserForMobile(string $mobile): ?User
    {
        try {
            $mobileColumn = collect(['mobile', 'phone', 'mobile_number'])
                ->first(fn (string $column) => Schema::hasColumn('users', $column));
            if (! $mobileColumn) return null;

            $user = User::query()->where($mobileColumn, $mobile)->first();
            if ($user) return $user;

            $user = new User();
            $user->forceFill([$mobileColumn => $mobile]);
            if (Schema::hasColumn('users', 'name')) $user->name = 'DuraCabs Customer';
            if (Schema::hasColumn('users', 'email')) $user->email = 'guest-' . $mobile . '@duracabs.local';
            if (Schema::hasColumn('users', 'password')) $user->password = bcrypt(Str::random(32));
            if (Schema::hasColumn('users', 'mobile_verified_at')) $user->mobile_verified_at = now();
            $user->save();
            return $user;
        } catch (\Throwable $e) {
            Log::warning('Could not create/login OTP user', ['error' => $e->getMessage()]);
            return null;
        }
    }

    private function createOrUpdateRideInquiry(string $mobile, mixed $userId = null): void
    {
        try {
            $landingUrl = request()->fullUrl();
            $source = request()->query('utm_source')
                ? 'utm:' . request()->query('utm_source')
                : (request()->query('gclid') ? 'google_ads' : 'seo_route_page');

            $lookup = RideInquiry::query()
                ->where('mobile', $mobile)
                ->where('pickup_name', (string) $this->nameTo)
                ->where('drop_name', (string) $this->nameFrom)
                ->where('trip_type', (string) ($this->tab ?: 'one_way'))
                ->whereDate('travel_date', $this->date ?: now()->toDateString())
                ->where('created_at', '>=', now()->subHours(24))
                ->latest()
                ->first();

            $payload = [
                'user_id' => $userId,
                'mobile' => $mobile,
                'pickup_city_id' => is_numeric($this->cityFrom) ? $this->cityFrom : null,
                'drop_city_id' => is_numeric($this->cityTo) ? $this->cityTo : null,
                'pickup_name' => (string) $this->nameTo,
                'drop_name' => (string) $this->nameFrom,
                'trip_type' => (string) ($this->tab ?: 'one_way'),
                'travel_date' => $this->date ?: now()->toDateString(),
                'travel_time' => $this->time ?: null,
                'return_date' => $this->dateto ?: null,
                'source' => $source,
                'landing_url' => $landingUrl,
                'utm_source' => request()->query('utm_source'),
                'utm_medium' => request()->query('utm_medium'),
                'utm_campaign' => request()->query('utm_campaign'),
                'gclid' => request()->query('gclid'),
                'fbclid' => request()->query('fbclid'),
                'status' => $lookup?->status ?: 'new',
                'last_activity_at' => now(),
            ];

            if ($lookup) {
                $lookup->update($payload);
            } else {
                $payload['inquiry_no'] = 'RI-' . now()->format('ymd') . '-' . strtoupper(Str::random(6));
                RideInquiry::create($payload);
            }
        } catch (\Throwable $e) {
            Log::error('Ride inquiry creation failed', ['error' => $e->getMessage()]);
        }
    }

    public function priceCalculate(){
       $day =  $this->days;
       $km =  $this->kmValue / 1000;

       return [];
    }

    // Edit Query Popup Methods
    public function showEditQueryModal() {
        $this->showEditModal = true;
        $this->edit_ride_type = $this->tab ?: 'one_way';
        
        // Pre-populate current values
        $this->edit_date = $this->date;
        $this->edit_dateto = $this->dateto;
        $this->edit_time = $this->time;
        $this->edit_endTime = $this->endTime;
        $this->edit_plan = $this->plan ?: '4 Hour / 40 Km';
        $this->edit_cars = $this->cars ?: 1;
        $this->edit_days = $this->days;
        $this->edit_km = $this->km;
        $this->edit_kmValue = $this->kmValue;
        $this->edit_timeValue = $this->timeValue;
        
        if ($this->edit_ride_type == 'one_way') {
            $this->edit_query_search = $this->nameTo;
            $this->edit_query2_search = $this->nameFrom;
            $this->edit_cityFrom_id = $this->cityFrom;
            $this->edit_cityTo_id = $this->cityTo;
        } elseif ($this->edit_ride_type == 'return') {
            $this->edit_queryFrom_search = $this->nameTo;
            $this->edit_queryTo_search = $this->nameFrom;
        } elseif ($this->edit_ride_type == 'local') {
            $this->edit_queryLocal = $this->nameTo;
            $this->edit_cityFrom_id = $this->cityFrom;
        } elseif ($this->edit_ride_type == 'self_drive') {
            $this->edit_querySelfDrive = $this->nameTo;
            $this->edit_cityFrom_id = $this->cityFrom;
        }
    }

    public function changeEditTab($value) {
        // Sync current values before switching
        $this->syncEditSearchValuesOnTabChange($value);
        $this->edit_ride_type = $value;
    }

    private function resetEditSearchFields() {
        // Clear dropdown data but keep search values
        $this->edit_cities_from = [];
        $this->edit_cities_to = [];
        $this->edit_dataFrom = [];
        $this->edit_dataTo = [];
    }

    /**
     * Sync search values when changing tabs in edit modal
     */
    private function syncEditSearchValuesOnTabChange($newTab) {
        $currentTab = $this->edit_ride_type;
        
        // Get current search values based on current tab
        $fromValue = $this->getCurrentEditFromValue($currentTab);
        $toValue = $this->getCurrentEditToValue($currentTab);
        $fromCityId = $this->getCurrentEditFromCityId($currentTab);
        $toCityId = $this->getCurrentEditToCityId($currentTab);
        
        // Set values for new tab if they exist and are compatible
        if ($fromValue) {
            if ($this->isValueCompatibleWithTab($fromValue, $newTab)) {
                $this->setEditFromValueForTab($newTab, $fromValue);
                $this->setEditFromSearchValueForTab($newTab, $fromValue);
            } else {
                // Clear the search field if the value won't work in the new tab
                $this->setEditFromSearchValueForTab($newTab, '');
            }
        }
        if ($toValue) {
            $this->setEditToValueForTab($newTab, $toValue);
            $this->setEditToSearchValueForTab($newTab, $toValue);
        }
        if ($fromCityId && $this->isValueCompatibleWithTab($fromValue, $newTab)) {
            $this->setEditFromCityIdForTab($newTab, $fromCityId);
        }
        if ($toCityId) {
            $this->setEditToCityIdForTab($newTab, $toCityId);
        }
    }

    /**
     * Get current edit "from" value based on tab
     */
    private function getCurrentEditFromValue($tab) {
        switch ($tab) {
            case 'one_way':
                return $this->edit_query_search;
            case 'return':
                return $this->edit_queryFrom_search;
            case 'local':
                return $this->edit_queryLocal;
            case 'self_drive':
                return $this->edit_querySelfDrive;
            default:
                return null;
        }
    }

    /**
     * Get current edit "to" value based on tab
     */
    private function getCurrentEditToValue($tab) {
        switch ($tab) {
            case 'one_way':
                return $this->edit_query2_search;
            case 'return':
                return $this->edit_queryTo_search;
            default:
                return null;
        }
    }

    /**
     * Set edit "from" value for specific tab
     */
    private function setEditFromValueForTab($tab, $value) {
        switch ($tab) {
            case 'one_way':
                $this->edit_query_search = $value;
                break;
            case 'return':
                $this->edit_queryFrom_search = $value;
                break;
            case 'local':
                $this->edit_queryLocal = $value;
                break;
            case 'self_drive':
                $this->edit_querySelfDrive = $value;
                break;
        }
    }

    /**
     * Set edit "to" value for specific tab
     */
    private function setEditToValueForTab($tab, $value) {
        switch ($tab) {
            case 'one_way':
                $this->edit_query2_search = $value;
                break;
            case 'return':
                $this->edit_queryTo_search = $value;
                break;
        }
    }

    /**
     * Get current edit "from" city ID based on tab
     */
    private function getCurrentEditFromCityId($tab) {
        switch ($tab) {
            case 'one_way':
                return $this->edit_cityFrom_id;
            case 'local':
                return $this->edit_cityFrom_id;
            case 'self_drive':
                return $this->edit_cityFrom_id;
            default:
                return null;
        }
    }

    /**
     * Get current edit "to" city ID based on tab
     */
    private function getCurrentEditToCityId($tab) {
        switch ($tab) {
            case 'one_way':
                return $this->edit_cityTo_id;
            default:
                return null;
        }
    }

    /**
     * Set edit "from" city ID for specific tab
     */
    private function setEditFromCityIdForTab($tab, $cityId) {
        switch ($tab) {
            case 'one_way':
                $this->edit_cityFrom_id = $cityId;
                break;
            case 'local':
                $this->edit_cityFrom_id = $cityId;
                break;
            case 'self_drive':
                $this->edit_cityFrom_id = $cityId;
                break;
        }
    }

    /**
     * Set edit "to" city ID for specific tab
     */
    private function setEditToCityIdForTab($tab, $cityId) {
        switch ($tab) {
            case 'one_way':
                $this->edit_cityTo_id = $cityId;
                break;
        }
    }

    /**
     * Set edit "from" search field value for specific tab (updates input field)
     */
    private function setEditFromSearchValueForTab($tab, $value) {
        switch ($tab) {
            case 'one_way':
                $this->edit_query_search = $value;
                break;
            case 'return':
                $this->edit_queryFrom_search = $value;
                break;
            case 'local':
                $this->edit_queryLocal = $value;
                break;
            case 'self_drive':
                $this->edit_querySelfDrive = $value;
                break;
        }
    }

    /**
     * Set edit "to" search field value for specific tab (updates input field)
     */
    private function setEditToSearchValueForTab($tab, $value) {
        switch ($tab) {
            case 'one_way':
                $this->edit_query2_search = $value;
                break;
            case 'return':
                $this->edit_queryTo_search = $value;
                break;
        }
    }

    /**
     * Check if a search value is compatible with a specific tab
     */
    private function isValueCompatibleWithTab($value, $tab) {
        if (empty($value)) {
            return true;
        }

        switch ($tab) {
            case 'local':
                // Check if there are local cities matching this value
                return Brand::where('name', 'like', '%' . $value . '%')
                    ->where('is_active', 1)
                    ->where('is_local', 1)
                    ->exists();
            
            case 'self_drive':
                // Check if there are self_drive cities matching this value
                return Brand::where('name', 'like', '%' . $value . '%')
                    ->where('is_active', 1)
                    ->where('is_selfdrive', 1)
                    ->exists();
            
            case 'one_way':
            case 'return':
            default:
                // One way and return accept all active cities
                return Brand::where('name', 'like', '%' . $value . '%')
                    ->where('is_active', 1)
                    ->exists();
        }
    }

    // One Way search handlers for popup
    public function updatedEditQuerySearch($query): void
    {
        $this->edit_cities_from = $this->searchBrands((string) $query);
    }

    public function updatedEditQuery2Search($query2): void
    {
        $this->edit_cities_to = $this->searchBrands((string) $query2);
    }

    // Local search handler for popup
    public function updatedEditQueryLocal($queryLocal): void
    {
        $this->edit_cities_from = $this->searchBrands((string) $queryLocal, 'is_local');
    }

    // Self Drive search handler for popup
    public function updatedEditQuerySelfDrive($querySelfDrive): void
    {
        $this->edit_cities_from = $this->searchBrands((string) $querySelfDrive, 'is_selfdrive');
    }

    // Return trip Google Places API handlers for popup
    public function updatedEditQueryFromSearch($queryFrom): void
    {
        $this->edit_dataFrom = $this->googlePlaceSuggestions((string) $queryFrom);
    }

    public function updatedEditQueryToSearch($queryTo): void
    {
        $this->edit_dataTo = $this->googlePlaceSuggestions((string) $queryTo);
    }

    /**
     * Small, cached autocomplete payload for Livewire dropdowns.
     */
    private function searchBrands(string $term, ?string $serviceColumn = null): array
    {
        $term = trim($term);

        if (mb_strlen($term) < 3) {
            return [];
        }

        $normalized = mb_strtolower($term);
        $cacheKey = 'rides:brand-search:' . ($serviceColumn ?: 'all') . ':' . md5($normalized);

        return Cache::remember($cacheKey, now()->addMinutes(10), function () use ($term, $serviceColumn): array {
            $query = Brand::query()
                ->select(['id', 'name', 'slug'])
                ->where('is_active', 1)
                ->where('name', 'like', $term . '%');

            if ($serviceColumn) {
                $query->where($serviceColumn, 1);
            }

            $results = $query->orderBy('name')->limit(10)->get();

            // Keep contains matching as a fallback without slowing the common prefix case.
            if ($results->isEmpty()) {
                $fallback = Brand::query()
                    ->select(['id', 'name', 'slug'])
                    ->where('is_active', 1)
                    ->where('name', 'like', '%' . $term . '%');

                if ($serviceColumn) {
                    $fallback->where($serviceColumn, 1);
                }

                $results = $fallback->orderBy('name')->limit(10)->get();
            }

            return $results->toArray();
        });
    }

    /**
     * Cache Google autocomplete briefly to avoid repeated paid API calls while typing.
     */
    private function googlePlaceSuggestions(string $term): array
    {
        $term = trim($term);

        if (blank($this->apiKey) || mb_strlen($term) < 3) {
            return [];
        }

        $cacheKey = 'rides:google-places:' . md5(mb_strtolower($term));

        return Cache::remember($cacheKey, now()->addMinutes(15), function () use ($term): array {
            try {
                $client = new Client([
                    'connect_timeout' => 2.5,
                    'timeout' => 5.0,
                    'http_errors' => false,
                ]);

                $response = $client->get(
                    'https://maps.googleapis.com/maps/api/place/queryautocomplete/json',
                    ['query' => ['input' => $term, 'key' => $this->apiKey]]
                );

                if ($response->getStatusCode() !== 200) {
                    Log::warning('Google Places autocomplete returned a non-200 response.', [
                        'status' => $response->getStatusCode(),
                    ]);
                    return [];
                }

                $data = json_decode((string) $response->getBody(), true);

                return array_slice($data['predictions'] ?? [], 0, 8);
            } catch (\Throwable $exception) {
                Log::warning('Google Places autocomplete failed.', [
                    'message' => $exception->getMessage(),
                ]);
                return [];
            }
        });
    }

    // City selection methods for popup
    public function editUpdateCityFrom($name) {
        $this->edit_queryFrom_search = $name;
        $this->edit_dataFrom = [];
    }

    public function editUpdateCityTo($name) {
        $this->edit_queryTo_search = $name;
        $this->edit_dataTo = [];
    }

    public function editUpdate1($name, $id) {
        $this->edit_query_search = $name;
        $this->edit_cityFrom_id = $id;
        $this->edit_cities_from = [];
    }

    public function editUpdate2($name, $id) {
        $this->edit_query2_search = $name;
        $this->edit_cityTo_id = $id;
        $this->edit_cities_to = [];
    }

    public function editUpdate3($name, $id) {
        $this->edit_queryLocal = $name;
        $this->edit_cityFrom_id = $id;
        $this->edit_cities_from = [];
    }

    public function editUpdate4($name, $id) {
        $this->edit_querySelfDrive = $name;
        $this->edit_cityFrom_id = $id;
        $this->edit_cities_from = [];
    }

    public function updateQuery() {
        // Set loading state
        $this->isLoading = true;
        
        try {
            // Validation based on ride type
            $this->validate($this->getEditValidationRules());

            // Build the redirect URL with updated parameters
            $params = $this->buildEditRedirectParams();
            
            $this->showEditModal = false;
            $this->isLoading = false;
            
            return redirect()->to(route('rides') . '?' . http_build_query($params));
        } catch (\Exception $e) {
            $this->isLoading = false;
            throw $e;
        }
    }

    private function getEditValidationRules() {
        $baseRules = [
            'edit_date' => 'required|date|after_or_equal:today',
            'edit_time' => 'required',
        ];

        switch ($this->edit_ride_type) {
            case 'one_way':
                return array_merge($baseRules, [
                    'edit_query_search' => 'required',
                    'edit_query2_search' => 'required',
                ]);
            case 'return':
                return array_merge($baseRules, [
                    'edit_queryFrom_search' => 'required',
                    'edit_queryTo_search' => 'required',
                    'edit_dateto' => 'required|date|after:edit_date',
                ]);
            case 'local':
                return array_merge($baseRules, [
                    'edit_queryLocal' => 'required',
                    'edit_plan' => 'required',
                    'edit_cars' => 'required|integer|min:1',
                ]);
            case 'self_drive':
                return array_merge($baseRules, [
                    'edit_querySelfDrive' => 'required',
                    'edit_dateto' => 'required|date|after_or_equal:edit_date',
                    'edit_endTime' => 'required',
                ]);
            default:
                return $baseRules;
        }
    }

    private function buildEditRedirectParams() {
        $params = [
            'tab' => $this->edit_ride_type,
            'date' => $this->edit_date,
            'time' => $this->edit_time,
        ];

        switch ($this->edit_ride_type) {
            case 'one_way':
                $params['cityFrom'] = $this->edit_cityFrom_id;
                $params['cityTo'] = $this->edit_cityTo_id;
                $params['nameTo'] = $this->edit_query_search;
                $params['nameFrom'] = $this->edit_query2_search;
                break;
            case 'return':
                $params['nameTo'] = $this->edit_queryFrom_search;
                $params['cityFrom'] = $this->edit_queryTo_search;
                $params['dateto'] = $this->edit_dateto;
                $params['km'] = $this->edit_km;
                $params['kmValue'] = $this->edit_kmValue;
                $params['timeValue'] = $this->edit_timeValue;
                $params['days'] = $this->edit_days;
                break;
            case 'local':
                $params['cityFrom'] = $this->edit_cityFrom_id;
                $params['nameTo'] = $this->edit_queryLocal;
                $params['plan'] = $this->edit_plan;
                $params['cars'] = $this->edit_cars;
                break;
            case 'self_drive':
                $params['cityFrom'] = $this->edit_cityFrom_id;
                $params['nameTo'] = $this->edit_querySelfDrive;
                $params['dateto'] = $this->edit_dateto;
                $params['endTime'] = $this->edit_endTime;
                $params['days'] = $this->edit_days;
                break;
        }

        return $params;
    }


    public function updatedSelectedCategories(): void
    {
        $this->resetPage();
    }

    public function updatedSelectedBrands(): void
    {
        $this->resetPage();
    }

    public function updatedPriceRange(): void
    {
        $this->resetPage();
    }

    public function updatedSort(): void
    {
        if (! in_array($this->sort, ['price', 'latest'], true)) {
            $this->sort = 'price';
        }

        $this->resetPage();
    }

    private function seoData(): array
    {
        $from = trim((string) $this->nameTo);
        $to = trim((string) $this->nameFrom);
        $tripType = (string) ($this->tab ?: 'one_way');

        $fallbackTitle = 'Duracabs: Trusted Online Cab Booking Services in India';
        $fallbackDescription = 'Book reliable one-way, round-trip, local and self-drive cab services with Duracabs. Compare available vehicles, view fare details and book online.';

        if ($tripType === 'local' && $from !== '') {
            $fallbackTitle = "{$from} Local Taxi Service | Duracabs";
            $fallbackDescription = "Book a local taxi in {$from} with Duracabs. Compare available cars, transparent fares and convenient online booking.";
        } elseif ($tripType === 'self_drive' && $from !== '') {
            $fallbackTitle = "Self Drive Cars in {$from} | Duracabs";
            $fallbackDescription = "Book self-drive cars in {$from} with Duracabs. Compare available vehicles, rental prices and trip details online.";
        } elseif ($tripType === 'return' && $from !== '' && $to !== '') {
            $fallbackTitle = "{$from} to {$to} Round Trip Taxi | Duracabs";
            $fallbackDescription = "Book a {$from} to {$to} round-trip taxi with Duracabs. Compare vehicles, check transparent fares and reserve your cab online.";
        } elseif ($from !== '' && $to !== '') {
            $fallbackTitle = "{$from} to {$to} One Way Taxi | Duracabs";
            $fallbackDescription = "Book a {$from} to {$to} one-way taxi with Duracabs. Compare available cars, view fare details and book securely online.";
        }

        $seoPage = Cache::remember('rides:seo-page', now()->addHours(6), fn () => SeoPage::query()
            ->select(['meta_title', 'meta_description', 'image'])
            ->whereIn('slug', ['rides', 'ride', 'cab-booking', 'taxi-booking'])
            ->first());

        $image = 'https://www.duracabs.com/img/logo/duracabs_logo.jpeg';
        if (filled($seoPage?->image)) {
            $image = str_starts_with($seoPage->image, 'http://') || str_starts_with($seoPage->image, 'https://')
                ? $seoPage->image
                : asset('storage/' . ltrim($seoPage->image, '/'));
        }

        return [
            'pageTitle' => filled($seoPage?->meta_title) ? $seoPage->meta_title : $fallbackTitle,
            'pageDescription' => filled($seoPage?->meta_description) ? $seoPage->meta_description : $fallbackDescription,
            'pageImage' => $image,
        ];
    }

    public function render()
    {
        $isSelfDrive = $this->tab === 'self_drive';

        if ($isSelfDrive) {
            $ridesQuery = Vehicle::query()
                ->with('transporter')
                ->availableForRental()
                ->selfDrive();

            if ($this->price_range) {
                $ridesQuery->whereBetween('hourly_price', [0, $this->price_range]);
            }

            if ($this->sort === 'latest') {
                $ridesQuery->latest();
            } else {
                $ridesQuery->orderByRaw('CASE WHEN hourly_price IS NULL THEN 1 ELSE 0 END')
                    ->orderBy('hourly_price');
            }
        } else {
            $ridesQuery = Product::query()->where('is_active', 1);

            if (! empty($this->selected_categories)) {
                $ridesQuery->where('category_id', $this->selected_categories);
            }

            if (! empty($this->selected_brands)) {
                $ridesQuery->where(function ($query) {
                    $query->where('brand_id', $this->selected_brands)
                        ->orWhere('booking_to', $this->selected_brands);
                });
            }

            if (! empty($this->cityFrom)) {
                $ridesQuery->where('brand_id', $this->cityFrom);
            }

            if (! empty($this->cityTo)) {
                $ridesQuery->where('booking_to', $this->cityTo);
            }

            if ($this->price_range) {
                $ridesQuery->whereBetween('price', [0, $this->price_range]);
            }

            if ($this->sort === 'latest') {
                $ridesQuery->latest();
            }

            if ($this->sort === 'price') {
                $ridesQuery->orderBy('price');
            }

            if (! empty($this->tab)) {
                $ridesQuery->where('ride_type', $this->tab);
            }

            if ($this->tab === 'local') {
                $ridesQuery->where('plan', $this->plan);
            }

            $ridesQuery->with(['prices.category']);
        }

        $brandsData = Cache::remember('rides:active-brands', now()->addMinutes(30), fn () => Brand::query()
            ->select(['id', 'name', 'slug'])
            ->where('is_active', 1)
            ->orderBy('name')
            ->get());
        $brandFilter = $this->query2 ? $this->brandsData : $brandsData;
        $seo = $this->seoData();
        $categories = Cache::remember('rides:active-categories', now()->addMinutes(30), fn () => Category::query()
            ->select(['id', 'name', 'slug', 'image', 'new_vehicle', 'pet_friendly', 'roof_career'])
            ->where('is_active', 1)
            ->orderBy('name')
            ->get());
        $returnCategories = Cache::remember('rides:return-categories', now()->addMinutes(30), fn () => Category::query()
            ->select(['id', 'name', 'slug', 'image', 'km_charge', 'driver_charge', 'range', 'new_vehicle', 'pet_friendly', 'roof_career'])
            ->where('in_return', 1)
            ->orderBy('name')
            ->get());

        return view('livewire.rides-page', [
            'rides' => $ridesQuery->paginate(perPage: 9),
            'isSelfDriveListing' => $isSelfDrive,
            'brands' => $brandFilter,
            'categories' => $categories,
            'categories2' => $returnCategories,
            'newTime' => $this->time ? DateTime::createFromFormat('H:i', $this->time) : false,
            'timeEnd' => $this->endTime ? DateTime::createFromFormat('H:i', $this->endTime) : false,
            'pageTitle' => $seo['pageTitle'],
            'pageDescription' => $seo['pageDescription'],
            'pageImage' => $seo['pageImage'],
        ]);
    }
}