<?php

namespace App\Livewire;

use App\Helpers\CartManagement;
use App\Livewire\Partials\Navbar;
use App\Models\Brand;
use App\Models\Product;
use App\Models\RideInquiry;
use App\Models\User;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Attributes\Title;
use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Illuminate\Support\Number;

#[Title('Ride Detail - Duracabs')]
class ProductDetailedPage extends Component
{

    use LivewireAlert;
   
    public $slug;
    public $hours = false;
    public $tab = false;
    public $date = false;
    public $time = false;

    public $endDate = false;
    public $endTime = false;
    public $plan = '4 Hour / 40 Km';
    public $cars = false;

    public $price = false;
    public $name = false;
    public $categoryName = false;
     public $toll = false;
    public $newVehical = false;
    public $petFrindly = false;
    public $roof_career = false;
    public $security = false;

    public $quantity = 1;

    // Same-page trip edit
    public bool $showEditTripModal = false;
    public ?int $editPickupId = null;
    public ?int $editDropId = null;
    public string $editRideType = 'one_way';
    public string $editDate = '';
    public string $editTime = '';
    public string $editEndDate = '';
    public string $editEndTime = '';

    // 4-digit OTP fare gate
    public bool $showOtpModal = false;
    public bool $fareUnlocked = false;
    public string $otpStage = 'mobile';
    public string $mobileNumber = '';
    public string $otpCode = '';
    public ?string $otpError = null;
    public ?array $pendingTabValue = null;

    public function mount($slug): void
    {
        $this->slug = $slug;
        $this->fareUnlocked = Auth::check() || (bool) session('route_fare_unlocked', false);
        $this->mobileNumber = (string) session('route_verified_mobile', '');
        $this->date = request()->query('date', '');
        $this->time = request()->query('time', '');
        $this->endDate = request()->query('end_date', '');
        $this->endTime = request()->query('end_time', '');
    }

    public function test()
{
    $this->quantity++;
    
}

public function addToCartOneWay($product_id){

    $total_count = CartManagement::addItemsToCartOneWay($product_id);

    $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

    $this->alert('success', 'Package Added to the cart successfully', [
        'position' => 'center-end',
        'timer' => 3000,
        'toast' => true,
       ]);

    redirect(route('checkout'));
}

public function addToCartLocal($product_id){
    $total_count = CartManagement::addItemsToCartLocal($product_id);

    $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

    $this->alert('success', 'Package Added to the cart successfully', [
        'position' => 'center-end',
        'timer' => 3000,
        'toast' => true,
       ]);

    redirect(route('checkout'));
}

public function addToCartSelfDrive($product_id){
    $total_count = CartManagement::addItemsToCartSelfDrive($product_id);

    $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

    $this->alert('success', 'Package Added to the cart successfully', [
        'position' => 'center-end',
        'timer' => 3000,
        'toast' => true,
       ]);

    redirect(route('checkout'));
}

public function submitOneWay($product_id){
  
   

    $this->validate([
        'date' => 'required',
        'time' => 'required',
    ]);

    $this->addToCartOneWay($product_id);    

}

public function submitLocal($product_id){

  
    $this->validate([
        'date' => 'required',
        'time' => 'required',
        'plan' => 'required',
    ]);

    $this->addToCartLocal($product_id);    

}

public function submitSelfDrive($product_id){

  
    $this->validate([
        'date' => 'required',
        'time' => 'required',
        'endDate' => 'required',
        'endTime' => 'required',
        
    ]);

      

    $this->addToCartSelfDrive($product_id);    

}

public function updatedEndDate() {
    $date1 = sprintf("%s %s", $this->date, $this->time);

    $date2 = sprintf("%s %s", $this->endDate, $this->endTime);

    $diff = abs(strtotime($date2) - strtotime($date1));

    $years = floor($diff / (365 * 60 * 60 * 24));
    $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
    $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));

    $hours = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24) / (60 * 60));

    $minuts = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24 - $hours * 60 * 60) / 60);

    $seconds = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24 - $hours * 60 * 60 - $minuts * 60));

    //dd($years, $months, $days, $hours, $minuts);

    $calculatehours =  $days * 24 + $hours;

    $hours = 24 < $calculatehours ?  $calculatehours : 24;

    $this->hours = $hours;
}

public function updatedEndTime() {
    $date1 = sprintf("%s %s", $this->date, $this->time);

    $date2 = sprintf("%s %s", $this->endDate, $this->endTime);

    $diff = abs(strtotime($date2) - strtotime($date1));

    $years = floor($diff / (365 * 60 * 60 * 24));
    $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
    $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));

    $hours = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24) / (60 * 60));

    $minuts = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24 - $hours * 60 * 60) / 60);

    $seconds = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24 - $hours * 60 * 60 - $minuts * 60));

    //dd($years, $months, $days, $hours, $minuts);

    $calculatehours =  $days * 24 + $hours;

    $hours = 24 < $calculatehours ?  $calculatehours : 24;

    $this->hours = $hours;
}

public function updatedTime() {
    $date1 = sprintf("%s %s", $this->date, $this->time);

    $date2 = sprintf("%s %s", $this->endDate, $this->endTime);

    $diff = abs(strtotime($date2) - strtotime($date1));

    $years = floor($diff / (365 * 60 * 60 * 24));
    $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
    $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));

    $hours = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24) / (60 * 60));

    $minuts = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24 - $hours * 60 * 60) / 60);

    $seconds = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24 - $hours * 60 * 60 - $minuts * 60));

    //dd($years, $months, $days, $hours, $minuts);

    $calculatehours =  $days * 24 + $hours;

    $hours = 24 < $calculatehours ?  $calculatehours : 24;

    $this->hours = $hours;
}

public function updatedDate() {
    $date1 = sprintf("%s %s", $this->date, $this->time);

    $date2 = sprintf("%s %s", $this->endDate, $this->endTime);

    $diff = abs(strtotime($date2) - strtotime($date1));

    $years = floor($diff / (365 * 60 * 60 * 24));
    $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
    $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));

    $hours = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24) / (60 * 60));

    $minuts = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24 - $hours * 60 * 60) / 60);

    $seconds = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24 - $hours * 60 * 60 - $minuts * 60));

    //dd($years, $months, $days, $hours, $minuts);

    $calculatehours =  $days * 24 + $hours;

    $hours = 24 < $calculatehours ?  $calculatehours : 24;

    $this->hours = $hours;
}


public function tabValue($val){

    if (! $this->fareUnlocked) {
        $this->pendingTabValue = is_array($val) ? $val : null;
        $this->openFareGate();
        return;
    }

    $this->tab = $val[0];
    $this->price = $val[1];
    $this->name = $val[2];
    $this->categoryName = $val[3];

    if($this->tab == 'one_way' || $this->tab == 'local'){
        $this->toll = $val[4];
        $this->newVehical = $val[5];
        $this->petFrindly = $val[6];
        $this->roof_career = $val[7];
    }

    if($this->tab == 'self_drive'){
        $this->security = $val[4];
       
    }
   
}
    

    

    public function increaseQty(){
        $this->quantity++;
    }

    public function decreaseQty(){
       if($this->quantity > 1){
        $this->quantity--;
       }
    }

    public function addToCart($product_id){
        $total_count = CartManagement::addItemsToCart($product_id);

        $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

        $this->alert('success', 'Package Added to the cart successfully', [
            'position' => 'center-end',
            'timer' => 3000,
            'toast' => true,
           ]);
        redirect(route('checkout'));
    }

    public function openFareGate(): void
    {
        if ($this->fareUnlocked) {
            return;
        }

        $this->showOtpModal = true;
        $this->otpStage = 'mobile';
        $this->otpCode = '';
        $this->otpError = null;
        $this->resetErrorBag();
    }

    public function closeOtpModal(): void
    {
        $this->showOtpModal = false;
        $this->otpCode = '';
        $this->otpError = null;
    }

    public function changeOtpMobile(): void
    {
        $this->otpStage = 'mobile';
        $this->otpCode = '';
        $this->otpError = null;
    }

    public function sendFareOtp(): void
    {
        $this->resetErrorBag();
        $this->otpError = null;

        $mobile = preg_replace('/\D+/', '', $this->mobileNumber);
        if (strlen($mobile) === 12 && str_starts_with($mobile, '91')) {
            $mobile = substr($mobile, 2);
        }

        if (! preg_match('/^[6-9]\d{9}$/', $mobile)) {
            $this->addError('mobileNumber', 'Valid 10 digit mobile number enter karein.');
            return;
        }

        $rateKey = 'route-fare-otp-send:' . $mobile . ':' . request()->ip();
        if ((int) Cache::get($rateKey, 0) >= 3) {
            $this->otpError = 'Bahut zyada OTP requests hui hain. 15 minute baad try karein.';
            return;
        }

        $otp = (string) random_int(1000, 9999);
        Cache::put('route-fare-otp:' . $mobile, [
            'hash' => hash('sha256', $otp),
            'attempts' => 0,
        ], now()->addMinutes(5));
        Cache::put($rateKey, (int) Cache::get($rateKey, 0) + 1, now()->addMinutes(15));

        $this->mobileNumber = $mobile;
        $this->otpStage = 'otp';
        $this->otpCode = '';
        $this->deliverFareOtp($mobile, $otp);
        $this->dispatch('route-otp-sent');
    }

    public function verifyFareOtp(): void
    {
        $this->resetErrorBag();
        $this->otpError = null;

        $mobile = preg_replace('/\D+/', '', $this->mobileNumber);
        $otp = preg_replace('/\D+/', '', $this->otpCode);

        if (! preg_match('/^\d{4}$/', $otp)) {
            $this->addError('otpCode', 'Complete 4 digit OTP enter karein.');
            return;
        }

        $key = 'route-fare-otp:' . $mobile;
        $stored = Cache::get($key);
        if (! is_array($stored)) {
            $this->otpError = 'OTP expire ho gaya. Naya OTP bhejein.';
            return;
        }

        $attempts = (int) ($stored['attempts'] ?? 0);
        if ($attempts >= 5) {
            Cache::forget($key);
            $this->otpError = 'Maximum attempts complete. Naya OTP bhejein.';
            return;
        }

        if (! hash_equals((string) ($stored['hash'] ?? ''), hash('sha256', $otp))) {
            $stored['attempts'] = $attempts + 1;
            Cache::put($key, $stored, now()->addMinutes(5));
            $this->otpError = 'OTP galat hai. Dobara try karein.';
            return;
        }

        Cache::forget($key);
        $user = $this->findOrCreateMobileUser($mobile);
        if ($user) {
            Auth::login($user, true);
        }

        session([
            'route_fare_unlocked' => true,
            'route_verified_mobile' => $mobile,
        ]);

        $this->fareUnlocked = true;
        $this->showOtpModal = false;
        $this->otpStage = 'mobile';
        $this->createOrUpdateInquiry($mobile, $user?->getKey());

        $pending = $this->pendingTabValue;
        $this->pendingTabValue = null;
        if ($pending) {
            $this->tabValue($pending);
        }
    }

    private function deliverFareOtp(string $mobile, string $otp): void
    {
        $message = "Your DuraCabs OTP is {$otp}. Valid for 5 minutes.";

        foreach (['App\\Services\\OtpService', 'App\\Services\\SMSService', 'App\\Services\\SmsService'] as $class) {
            if (! class_exists($class)) {
                continue;
            }

            try {
                $service = app($class);
                foreach (['sendOtp', 'send', 'sendSMS'] as $method) {
                    if (method_exists($service, $method)) {
                        try {
                            $service->{$method}($mobile, $otp, $message);
                        } catch (\ArgumentCountError) {
                            try {
                                $service->{$method}($mobile, $message);
                            } catch (\ArgumentCountError) {
                                $service->{$method}($mobile, $otp);
                            }
                        }
                        return;
                    }
                }
            } catch (\Throwable $e) {
                Log::warning('Route fare OTP provider failed', ['error' => $e->getMessage()]);
            }
        }

        // Local testing fallback: storage/logs/laravel.log
        Log::info('DuraCabs route fare OTP', ['mobile' => $mobile, 'otp' => $otp]);
    }

    private function findOrCreateMobileUser(string $mobile): ?User
    {
        try {
            $mobileColumn = collect(['mobile', 'phone', 'mobile_number'])
                ->first(fn (string $column) => Schema::hasColumn('users', $column));

            if (! $mobileColumn) {
                return null;
            }

            $user = User::query()->where($mobileColumn, $mobile)->first();
            if ($user) {
                return $user;
            }

            $user = new User();
            $values = [$mobileColumn => $mobile];
            if (Schema::hasColumn('users', 'name')) {
                $values['name'] = 'DuraCabs Customer';
            }
            if (Schema::hasColumn('users', 'email')) {
                $values['email'] = 'customer-' . $mobile . '@duracabs.local';
            }
            if (Schema::hasColumn('users', 'password')) {
                $values['password'] = bcrypt(Str::random(40));
            }
            if (Schema::hasColumn('users', 'mobile_verified_at')) {
                $values['mobile_verified_at'] = now();
            }
            $user->forceFill($values)->save();
            return $user;
        } catch (\Throwable $e) {
            Log::warning('OTP user login/create failed', ['error' => $e->getMessage()]);
            return null;
        }
    }

    private function createOrUpdateInquiry(string $mobile, mixed $userId = null): void
    {
        try {
            $ride = Product::query()->with(['brand', 'prices'])->where('slug', $this->slug)->firstOrFail();
            $drop = Brand::query()->find($ride->booking_to);
            $travelDate = $this->date ?: now()->toDateString();
            $lowestFare = $ride->prices->min('price');

            $inquiry = RideInquiry::query()
                ->where('mobile', $mobile)
                ->where('pickup_city_id', $ride->brand_id)
                ->where('drop_city_id', $ride->booking_to)
                ->where('trip_type', $ride->ride_type ?: 'one_way')
                ->whereDate('travel_date', $travelDate)
                ->where('created_at', '>=', now()->subHours(24))
                ->latest()
                ->first();

            $payload = [
                'user_id' => $userId,
                'mobile' => $mobile,
                'pickup_city_id' => $ride->brand_id,
                'drop_city_id' => $ride->booking_to,
                'pickup_name' => $ride->brand?->name,
                'drop_name' => $drop?->name,
                'trip_type' => $ride->ride_type ?: 'one_way',
                'travel_date' => $travelDate,
                'travel_time' => $this->time ?: null,
                'return_date' => $this->endDate ?: null,
                'estimated_fare_from' => $lowestFare,
                'source' => request()->query('gclid') ? 'google_ads' : (request()->query('utm_source') ? 'utm:' . request()->query('utm_source') : 'seo_route_page'),
                'landing_url' => request()->fullUrl(),
                'utm_source' => request()->query('utm_source'),
                'utm_medium' => request()->query('utm_medium'),
                'utm_campaign' => request()->query('utm_campaign'),
                'gclid' => request()->query('gclid'),
                'fbclid' => request()->query('fbclid'),
                'status' => $inquiry?->status ?: 'new',
                'last_activity_at' => now(),
            ];

            if ($inquiry) {
                $inquiry->update($payload);
            } else {
                $payload['inquiry_no'] = 'RI-' . now()->format('ymd') . '-' . strtoupper(Str::random(6));
                RideInquiry::create($payload);
            }
        } catch (\Throwable $e) {
            Log::error('Route inquiry create/update failed', ['error' => $e->getMessage()]);
        }
    }

    public function openEditTripModal(): void
    {
        $ride = Product::query()->where('slug', $this->slug)->firstOrFail();
        $this->editPickupId = $ride->brand_id ? (int) $ride->brand_id : null;
        $this->editDropId = $ride->booking_to ? (int) $ride->booking_to : null;
        $this->editRideType = (string) ($ride->ride_type ?: 'one_way');
        $this->editDate = (string) ($this->date ?: now()->toDateString());
        $this->editTime = (string) ($this->time ?: '10:00');
        $this->editEndDate = (string) ($this->endDate ?: '');
        $this->editEndTime = (string) ($this->endTime ?: '');
        $this->showEditTripModal = true;
    }

    public function closeEditTripModal(): void
    {
        $this->showEditTripModal = false;
    }

    public function updateTripSearch()
    {
        $rules = [
            'editPickupId' => ['required', 'integer'],
            'editDate' => ['required', 'date', 'after_or_equal:today'],
            'editTime' => ['required'],
        ];

        if ($this->editRideType === 'one_way') {
            $rules['editDropId'] = ['required', 'integer', 'different:editPickupId'];
        }
        if ($this->editRideType === 'self_drive') {
            $rules['editEndDate'] = ['required', 'date', 'after_or_equal:editDate'];
            $rules['editEndTime'] = ['required'];
        }
        $this->validate($rules);

        $query = Product::query()
            ->where('is_active', 1)
            ->where('brand_id', $this->editPickupId)
            ->where('ride_type', $this->editRideType);

        if ($this->editRideType === 'one_way') {
            $query->where('booking_to', $this->editDropId);
        }

        $target = $query->first();
        if (! $target) {
            $this->addError('editPickupId', 'Is route ke liye active package nahi mila.');
            return null;
        }

        $params = array_filter([
            'date' => $this->editDate,
            'time' => $this->editTime,
            'end_date' => $this->editEndDate,
            'end_time' => $this->editEndTime,
        ]);

        return redirect()->route('route.show', ['slug' => $target->slug] + $params);
    }

    public function render()
    {
        $ride = Product::query()
            ->with(['brand', 'prices.category', 'links'])
            ->where('slug', $this->slug)
            ->where('is_active', 1)
            ->firstOrFail();

        $cityTo = ! empty($ride->booking_to)
            ? Brand::query()->find($ride->booking_to)
            : null;

        $prices = $ride->prices;
        $links = $ride->links;

        $ridesQuery = Product::query()
            ->with(['brand'])
            ->where('is_active', 1)
            ->whereKeyNot($ride->getKey());

        if (! empty($ride->brand_id)) {
            $ridesQuery->where('brand_id', $ride->brand_id);
        }

        if (! empty($ride->ride_type)) {
            $ridesQuery->where('ride_type', $ride->ride_type);
        }

        $contentType = (string) ($ride->content_type ?: 'route');
        $urlType = (string) ($ride->url_type ?: 'route');

        $pickupName = trim((string) ($ride->brand?->name ?: $ride->name ?: 'Dura Cabs'));
        $dropName = trim((string) ($cityTo?->name ?: ''));

        $tripLabel = match ($ride->ride_type) {
            'local' => 'Local Cab',
            'self_drive' => 'Self Drive Car',
            'round_trip' => 'Round Trip Taxi',
            'airport' => 'Airport Taxi',
            default => 'One Way Taxi',
        };

        $routeName = match ($contentType) {
            'blog', 'page', 'landing_page', 'product' => trim((string) ($ride->name ?: $pickupName)),
            default => $ride->ride_type === 'one_way' && $dropName !== ''
                ? "{$pickupName} to {$dropName}"
                : $pickupName,
        };

        $seoTitle = filled($ride->meta_title)
            ? trim((string) $ride->meta_title)
            : $this->buildFallbackSeoTitle($ride, $routeName, $tripLabel, $contentType);

        $lowestFare = $prices->min('price');
        $fareText = $lowestFare
            ? ' Fares start from ' . Number::currency((float) $lowestFare, 'INR') . '.'
            : '';

        $seoDescription = filled($ride->meta_description)
            ? trim((string) $ride->meta_description)
            : $this->buildFallbackSeoDescription($routeName, $tripLabel, $contentType, $fareText);

        $canonicalUrl = filled($ride->canonical_url)
            ? trim((string) $ride->canonical_url)
            : $this->resolveCanonicalUrl($ride, $urlType);

        $firstImage = collect($ride->images ?? [])->filter()->first();
        $imageMeta = $this->resolveSeoImage($ride, $firstImage);

        $metaKeywords = $this->normaliseKeywords($ride->meta_keywords ?? null, $ride->focus_keyword ?? null);
        $robots = filled($ride->robots) ? trim((string) $ride->robots) : 'index,follow';

        $openGraph = [
            'title' => filled($ride->og_title) ? trim((string) $ride->og_title) : $seoTitle,
            'description' => filled($ride->og_description) ? trim((string) $ride->og_description) : $seoDescription,
            'image' => filled($ride->og_image) ? $this->normaliseAssetUrl((string) $ride->og_image) : $imageMeta,
            'type' => $contentType === 'blog' ? 'article' : 'website',
            'url' => $canonicalUrl,
        ];

        $twitter = [
            'card' => 'summary_large_image',
            'title' => filled($ride->twitter_title) ? trim((string) $ride->twitter_title) : $seoTitle,
            'description' => filled($ride->twitter_description) ? trim((string) $ride->twitter_description) : $seoDescription,
            'image' => filled($ride->twitter_image) ? $this->normaliseAssetUrl((string) $ride->twitter_image) : $imageMeta,
        ];

        $faqs = $this->buildFaqs($ride, $routeName, $tripLabel, $lowestFare);

        $serviceSchema = $this->buildServiceSchema(
            $ride,
            $canonicalUrl,
            $seoTitle,
            $seoDescription,
            $imageMeta,
            $tripLabel,
            $pickupName,
            $dropName,
            $lowestFare,
            $prices->count(),
            $contentType
        );

        $faqSchema = [
            '@context' => 'https://schema.org',
            '@type' => 'FAQPage',
            '@id' => $canonicalUrl . '#faq',
            'mainEntity' => collect($faqs)->map(fn (array $faq) => [
                '@type' => 'Question',
                'name' => $faq['question'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text' => $faq['answer'],
                ],
            ])->values()->all(),
        ];

        $breadcrumbSchema = [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            '@id' => $canonicalUrl . '#breadcrumb',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Home',
                    'item' => url('/'),
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => $routeName,
                    'item' => $canonicalUrl,
                ],
            ],
        ];

        $customSchema = $this->normaliseCustomSchema($ride->schema ?? null);

        return view('livewire.product-detailed-page', [
            'ride' => $ride,
            'rides' => $ridesQuery->paginate(9),
            'cityTo' => $cityTo,
            'links' => $links,
            'prices' => $prices,
            'imageMeta' => $imageMeta,
            'allCities' => Brand::query()->orderBy('name')->get(['id', 'name']),
            'seoTitle' => $seoTitle,
            'seoDescription' => $seoDescription,
            'metaKeywords' => $metaKeywords,
            'robots' => $robots,
            'canonicalUrl' => $canonicalUrl,
            'routeName' => $routeName,
            'tripLabel' => $tripLabel,
            'contentType' => $contentType,
            'urlType' => $urlType,
            'openGraph' => $openGraph,
            'twitter' => $twitter,
            'faqs' => $faqs,
            'serviceSchema' => $serviceSchema,
            'faqSchema' => $faqSchema,
            'breadcrumbSchema' => $breadcrumbSchema,
            'customSchema' => $customSchema,
            'contentLinks' => collect($ride->content_links ?? [])->filter()->values(),
            'fareCards' => collect($ride->fare_cards ?? [])->filter()->values(),
            'linkedProducts' => collect($ride->link_products ?? [])->filter()->values(),
        ]);
    }

    private function buildFallbackSeoTitle(Product $ride, string $routeName, string $tripLabel, string $contentType): string
    {
        return match ($contentType) {
            'blog' => "{$routeName} | Dura Cabs Blog",
            'page' => "{$routeName} | Dura Cabs",
            'landing_page' => "{$routeName} | Book with Dura Cabs",
            'product' => "{$routeName} | Dura Cabs",
            default => "{$routeName} {$tripLabel} Booking | Dura Cabs",
        };
    }

    private function buildFallbackSeoDescription(string $routeName, string $tripLabel, string $contentType, string $fareText): string
    {
        return match ($contentType) {
            'blog' => "Read useful travel information, cab booking guidance and local tips about {$routeName} from Dura Cabs.",
            'page' => "Learn more about {$routeName} and book reliable cab services with Dura Cabs.",
            'landing_page' => "Book {$routeName} with verified drivers, clean cars and transparent pricing through Dura Cabs.{$fareText}",
            'product' => "Explore {$routeName}, pricing, availability and booking details with Dura Cabs.",
            default => "Book {$routeName} {$tripLabel} with verified drivers, clean cars and transparent pricing.{$fareText} Check available cabs and reserve online with Dura Cabs.",
        };
    }

    private function resolveCanonicalUrl(Product $ride, string $urlType): string
    {
        $slug = trim((string) $ride->slug, '/');

        return match ($urlType) {
            'page' => url('/pages/' . $slug),
            'blog' => url('/blog/' . $slug),
            'product' => url('/product/' . $slug),
            'root', 'landing_page' => url('/' . $slug),
            default => route('route.show', ['slug' => $slug]),
        };
    }

    private function resolveSeoImage(Product $ride, mixed $firstImage): string
    {
        foreach ([$ride->image ?? null, $firstImage] as $image) {
            if (filled($image)) {
                return $this->normaliseAssetUrl((string) $image);
            }
        }

        return asset('img/logo/favicon_duracabs.ico');
    }

    private function normaliseAssetUrl(string $path): string
    {
        $path = trim($path);

        if (Str::startsWith($path, ['http://', 'https://'])) {
            return $path;
        }

        if (Str::startsWith($path, ['/storage/', 'storage/'])) {
            return url('/' . ltrim($path, '/'));
        }

        return url('/storage/' . ltrim($path, '/'));
    }

    private function normaliseKeywords(mixed $keywords, mixed $focusKeyword): string
    {
        $items = [];

        if (is_array($keywords)) {
            $items = $keywords;
        } elseif (is_string($keywords)) {
            $items = preg_split('/[,\n]+/', $keywords) ?: [];
        }

        if (filled($focusKeyword)) {
            array_unshift($items, (string) $focusKeyword);
        }

        return collect($items)
            ->map(fn ($item) => trim((string) $item))
            ->filter()
            ->unique(fn ($item) => Str::lower($item))
            ->implode(', ');
    }

    private function buildFaqs(Product $ride, string $routeName, string $tripLabel, mixed $lowestFare): array
    {
        $customFaqs = collect($ride->faqs ?? [])
            ->map(function ($faq) {
                if (! is_array($faq)) {
                    return null;
                }

                $question = trim((string) Arr::get($faq, 'question', ''));
                $answer = trim((string) Arr::get($faq, 'answer', ''));

                return $question !== '' && $answer !== ''
                    ? ['question' => $question, 'answer' => $answer]
                    : null;
            })
            ->filter()
            ->values()
            ->all();

        if ($customFaqs !== []) {
            return $customFaqs;
        }

        return [
            [
                'question' => "What cab options are available for {$routeName}?",
                'answer' => "Dura Cabs offers multiple vehicle categories for {$routeName}, subject to live availability. Select a suitable cab and verify your mobile number to view the exact fare.",
            ],
            [
                'question' => "What is the minimum cab fare for {$routeName}?",
                'answer' => $lowestFare
                    ? 'The currently listed fare starts from ' . Number::currency((float) $lowestFare, 'INR') . '. The final payable amount depends on the selected vehicle, trip details, taxes and applicable extras.'
                    : 'The fare depends on the selected vehicle and trip details. Verify your mobile number on this page to view the latest available price.',
            ],
            [
                'question' => "How can I book {$tripLabel} for {$routeName}?",
                'answer' => 'Choose your vehicle, enter the pickup date and time, verify your mobile number, review the fare details and continue to checkout.',
            ],
            [
                'question' => 'Are toll, parking and taxes included in the displayed fare?',
                'answer' => 'Inclusions vary by package. Review the fare breakdown shown for the selected vehicle before booking. Toll, parking, state tax or other route-specific charges may be payable separately when marked as excluded.',
            ],
            [
                'question' => 'Can I change my trip details before booking?',
                'answer' => 'Yes. Use the Edit Trip option on this page to change the pickup city, destination, trip type, date or time before proceeding.',
            ],
        ];
    }

    private function buildServiceSchema(
        Product $ride,
        string $canonicalUrl,
        string $seoTitle,
        string $seoDescription,
        string $imageMeta,
        string $tripLabel,
        string $pickupName,
        string $dropName,
        mixed $lowestFare,
        int $offerCount,
        string $contentType
    ): array {
        if ($contentType === 'blog') {
            return [
                '@context' => 'https://schema.org',
                '@type' => 'Article',
                '@id' => $canonicalUrl . '#article',
                'headline' => $seoTitle,
                'description' => $seoDescription,
                'url' => $canonicalUrl,
                'image' => [$imageMeta],
                'datePublished' => optional($ride->created_at)?->toAtomString(),
                'dateModified' => optional($ride->updated_at)?->toAtomString(),
                'author' => [
                    '@type' => 'Organization',
                    'name' => 'Dura Cabs',
                ],
                'publisher' => [
                    '@type' => 'Organization',
                    'name' => 'Dura Cabs',
                    'url' => url('/'),
                ],
            ];
        }

        return array_filter([
            '@context' => 'https://schema.org',
            '@type' => $contentType === 'product' ? 'Product' : 'Service',
            '@id' => $canonicalUrl . '#service',
            'name' => $seoTitle,
            'description' => $seoDescription,
            'url' => $canonicalUrl,
            'image' => $imageMeta,
            'serviceType' => $contentType === 'product' ? null : $tripLabel,
            'provider' => [
                '@id' => url('/') . '#business',
            ],
            'areaServed' => $contentType === 'product' ? null : array_values(array_filter([
                ['@type' => 'City', 'name' => $pickupName],
                $ride->ride_type === 'one_way' && $dropName !== '' ? ['@type' => 'City', 'name' => $dropName] : null,
            ])),
            'offers' => $lowestFare ? [
                '@type' => $offerCount > 1 ? 'AggregateOffer' : 'Offer',
                'priceCurrency' => 'INR',
                $offerCount > 1 ? 'lowPrice' : 'price' => (float) $lowestFare,
                'offerCount' => $offerCount > 1 ? $offerCount : null,
                'availability' => 'https://schema.org/InStock',
                'url' => $canonicalUrl,
            ] : null,
        ], static fn ($value) => $value !== null && $value !== '' && $value !== []);
    }

    private function normaliseCustomSchema(mixed $schema): array
    {
        if (is_array($schema)) {
            return $schema;
        }

        if (is_string($schema) && trim($schema) !== '') {
            $decoded = json_decode($schema, true);
            return is_array($decoded) ? $decoded : [];
        }

        return [];
    }
}