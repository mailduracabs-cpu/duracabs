<?php

namespace App\Helpers;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Models\Vehicle;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cookie;

class CartManagement
{
    /**
     * Add a normal product to cart.
     */
    public static function addItemsToCart($product_id)
    {
        $cart_items = [];

        $product = Product::query()
            ->where('id', $product_id)
            ->first([
                'id',
                'name',
                'brand_id',
                'images',
                'price',
                'booking_to',
                'category_id',
                'ride_type',
            ]);

        if (!$product) {
            return 0;
        }

        $cityFrom = Brand::query()
            ->where('id', $product->brand_id)
            ->first(['id', 'name']);

        $cityTo = Brand::query()
            ->where('id', $product->booking_to)
            ->first(['id', 'name']);

        $cabModel = Category::query()
            ->where('id', $product->category_id)
            ->first(['id', 'name']);

        $cart_items[] = [
            'product_id' => $product->id,
            'name' => $product->name,
            'image' => self::firstProductImage($product),
            'quantity' => 1,
            'unit_ammount' => (float) $product->price,
            'total_ammount' => (float) $product->price,
            'cityFrom' => $cityFrom?->name ?? '',
            'cityTo' => $cityTo?->name ?? '',
            'cabModel' => $cabModel?->name ?? '',
            'type' => $product->ride_type,
            'item_source' => 'product',
        ];

        self::addCartItemsToCookie($cart_items);

        return count($cart_items);
    }

    /**
     * Add a one-way ride to cart.
     *
     * Existing array format is retained:
     * 0 product id
     * 1 time
     * 2 ride type
     * 3 date
     * 4 total amount
     * 5 display name
     * 6 cab model
     * 7 toll
     * 8 new vehicle
     * 9 pet friendly
     * 10 roof carrier
     */
    public static function addItemsToCartOneWay($product_id)
    {
        $cart_items = [];

        if (!is_array($product_id) || !isset($product_id[0])) {
            return 0;
        }

        $product = Product::query()
            ->where('id', $product_id[0])
            ->first([
                'id',
                'name',
                'brand_id',
                'images',
                'price',
                'booking_to',
                'category_id',
            ]);

        if (!$product) {
            return 0;
        }

        $cityFrom = Brand::query()
            ->where('id', $product->brand_id)
            ->first(['id', 'name']);

        $cityTo = Brand::query()
            ->where('id', $product->booking_to)
            ->first(['id', 'name']);

        $amount = (float) ($product_id[4] ?? $product->price ?? 0);

        $cart_items[] = [
            'product_id' => $product->id,
            'name' => $product_id[5] ?? $product->name,
            'image' => self::firstProductImage($product),
            'quantity' => 1,
            'unit_ammount' => $amount,
            'total_ammount' => $amount,
            'cityFrom' => $cityFrom?->name ?? '',
            'cityTo' => $cityTo?->name ?? '',
            'cabModel' => $product_id[6] ?? '',
            'date' => $product_id[3] ?? null,
            'type' => $product_id[2] ?? 'one_way',
            'time' => $product_id[1] ?? null,
            'toll' => (float) ($product_id[7] ?? 0),
            'new_vehicle' => $product_id[8] ?? false,
            'pet_friendly' => $product_id[9] ?? false,
            'roof_career' => $product_id[10] ?? false,
            'item_source' => 'product',
        ];

        self::addCartItemsToCookie($cart_items);

        return count($cart_items);
    }

    /**
     * Add a local ride to cart.
     */
    public static function addItemsToCartLocal($product_id)
    {
        $cart_items = [];

        if (!is_array($product_id) || !isset($product_id[0])) {
            return 0;
        }

        $product = Product::query()
            ->where('id', $product_id[0])
            ->first([
                'id',
                'name',
                'brand_id',
                'images',
                'price',
                'booking_to',
                'category_id',
            ]);

        if (!$product) {
            return 0;
        }

        $cityFrom = Brand::query()
            ->where('id', $product->brand_id)
            ->first(['id', 'name']);

        $cityTo = Brand::query()
            ->where('id', $product->booking_to)
            ->first(['id', 'name']);

        $amount = (float) ($product_id[6] ?? $product->price ?? 0);

        $cart_items[] = [
            'product_id' => $product->id,
            'name' => $product_id[7] ?? $product->name,
            'image' => self::firstProductImage($product),
            'quantity' => 1,
            'unit_ammount' => $amount,
            'total_ammount' => $amount,
            'cityFrom' => $cityFrom?->name ?? '',
            'cityTo' => $cityTo?->name ?? '',
            'cabModel' => $product_id[8] ?? '',
            'date' => $product_id[3] ?? null,
            'type' => $product_id[2] ?? 'local',
            'time' => $product_id[1] ?? null,
            'plan' => $product_id[4] ?? null,
            'car' => $product_id[5] ?? null,
            'toll' => (float) ($product_id[9] ?? 0),
            'new_vehicle' => $product_id[10] ?? false,
            'pet_friendly' => $product_id[11] ?? false,
            'roof_career' => $product_id[12] ?? false,
            'item_source' => 'product',
        ];

        self::addCartItemsToCookie($cart_items);

        return count($cart_items);
    }

    /**
     * Add a self-drive Vehicle to cart.
     *
     * New usage:
     * CartManagement::addItemsToCartSelfDrive($vehicleId, [
     *     'pickup_location' => 'Agra',
     *     'start_date' => '2026-07-20',
     *     'start_time' => '10:00',
     *     'end_date' => '2026-07-22',
     *     'end_time' => '10:00',
     * ]);
     *
     * The second argument is optional so the method also works when only
     * vehicle_id is sent from the listing page.
     */
    public static function addItemsToCartSelfDrive($vehicle_id, array $bookingData = [])
    {
        $cart_items = [];

        /*
         * Temporary backward compatibility:
         * If an old array is received, take its first value as vehicle id
         * and map its old date/time values when available.
         */
        if (is_array($vehicle_id)) {
            $oldData = $vehicle_id;
            $vehicle_id = $oldData[0] ?? null;

            $bookingData = array_merge([
                'start_time' => $oldData[1] ?? null,
                'end_time' => $oldData[2] ?? null,
                'type' => $oldData[3] ?? 'self_drive',
                'start_date' => $oldData[4] ?? null,
                'end_date' => $oldData[5] ?? null,
                'total_amount' => $oldData[6] ?? null,
                'security_deposit' => $oldData[7] ?? null,
            ], $bookingData);
        }

        if (!$vehicle_id) {
            return 0;
        }

        $vehicle = Vehicle::query()->find($vehicle_id);

        if (!$vehicle) {
            return 0;
        }

        self::loadVehicleOwnerRelation($vehicle);

        $startDate = $bookingData['start_date']
            ?? $bookingData['date']
            ?? session('self_drive.start_date')
            ?? session('self_drive.date');

        $endDate = $bookingData['end_date']
            ?? $bookingData['dateTo']
            ?? session('self_drive.end_date')
            ?? session('self_drive.dateTo');

        $startTime = $bookingData['start_time']
            ?? $bookingData['time']
            ?? session('self_drive.start_time')
            ?? session('self_drive.time');

        $endTime = $bookingData['end_time']
            ?? $bookingData['endTime']
            ?? session('self_drive.end_time')
            ?? session('self_drive.endTime');

        $rentalDays = self::calculateRentalDays(
            $startDate,
            $endDate,
            $startTime,
            $endTime
        );

        $dailyPrice = (float) (
            $vehicle->daily_price
            ?? $vehicle->price_per_day
            ?? $vehicle->rent_per_day
            ?? $vehicle->price
            ?? 0
        );

        $weeklyPrice = (float) (
            $vehicle->weekly_price
            ?? ($dailyPrice * 7)
        );

        $monthlyPrice = (float) (
            $vehicle->monthly_price
            ?? ($dailyPrice * 30)
        );

        $calculatedAmount = self::calculateSelfDriveRent(
            $rentalDays,
            $dailyPrice,
            $weeklyPrice,
            $monthlyPrice
        );

        $totalAmount = isset($bookingData['total_amount'])
            && is_numeric($bookingData['total_amount'])
                ? (float) $bookingData['total_amount']
                : $calculatedAmount;

        $securityDeposit = isset($bookingData['security_deposit'])
            && is_numeric($bookingData['security_deposit'])
                ? (float) $bookingData['security_deposit']
                : (float) ($vehicle->security_deposit ?? 0);

        $vendorName = self::vehicleVendorName($vehicle);

        $cart_items[] = [
            /*
             * vehicle_id is the new authoritative id.
             * product_id is retained temporarily because old checkout/remove
             * code may still read this key.
             */
            'vehicle_id' => $vehicle->id,
            'product_id' => $vehicle->id,
            'item_source' => 'vehicle',

            'name' => self::vehicleDisplayName($vehicle),
            'image' => self::vehicleImage($vehicle),
            'quantity' => 1,

            /*
             * Keep the old misspelled keys because the current checkout code
             * already depends on them.
             */
            'unit_ammount' => $dailyPrice,
            'total_ammount' => $totalAmount,

            /*
             * Correctly spelled aliases for new code.
             */
            'unit_amount' => $dailyPrice,
            'total_amount' => $totalAmount,

            'daily_price' => $dailyPrice,
            'weekly_price' => $weeklyPrice,
            'monthly_price' => $monthlyPrice,
            'rental_days' => $rentalDays,

            'security' => $securityDeposit,
            'security_deposit' => $securityDeposit,

            'vendor_name' => $vendorName,
            'transporter_name' => $vendorName,

            'fuel_type' => $vehicle->fuel_type ?? '',
            'transmission' => $vehicle->transmission ?? '',
            'seats' => $vehicle->seats ?? $vehicle->seating_capacity ?? null,

            'cityFrom' => $bookingData['pickup_location']
                ?? $bookingData['cityFrom']
                ?? session('self_drive.pickup_location')
                ?? '',

            'cityTo' => $bookingData['drop_location']
                ?? $bookingData['cityTo']
                ?? session('self_drive.drop_location')
                ?? '',

            'cabModel' => self::vehicleDisplayName($vehicle),
            'type' => $bookingData['type'] ?? 'self_drive',

            'date' => $startDate,
            'dateTo' => $endDate,
            'time' => $startTime,
            'endTime' => $endTime,

            'pickup_latitude' => $bookingData['pickup_latitude']
                ?? session('self_drive.pickup_latitude'),

            'pickup_longitude' => $bookingData['pickup_longitude']
                ?? session('self_drive.pickup_longitude'),

            'toll' => 0,
        ];

        self::addCartItemsToCookie($cart_items);

        return count($cart_items);
    }

    /**
     * Add return-trip data to cart.
     */
    public static function addItemsToCartReturn($data)
    {
        $cart_items = [];

        if (!is_array($data)) {
            return 0;
        }

        $product = Product::query()
            ->where('id', 5)
            ->first([
                'id',
                'name',
                'brand_id',
                'images',
                'price',
                'booking_to',
                'category_id',
            ]);

        $cabModel = Category::query()
            ->where('id', $data[0] ?? null)
            ->first(['id', 'name', 'image']);

        if (!$product || !$cabModel) {
            return 0;
        }

        $amount = (float) ($data[3] ?? 0);

        $cart_items[] = [
            'product_id' => 1686,
            'name' => $cabModel->name,
            'image' => $cabModel->image,
            'quantity' => 1,
            'unit_ammount' => $amount,
            'total_ammount' => $amount,
            'cityFrom' => $data[1] ?? '',
            'cityTo' => $data[2] ?? '',
            'date' => $data[4] ?? null,
            'dateTo' => $data[5] ?? null,
            'cabModel' => $cabModel->name,
            'time' => $data[6] ?? null,
            'type' => 'return',
            'TotalKm' => $data[8] ?? 0,
            'new_vehicle' => $data[9] ?? false,
            'pet_friendly' => $data[10] ?? false,
            'roof_career' => $data[11] ?? false,
            'toll' => 0,
            'item_source' => 'product',
        ];

        self::addCartItemsToCookie($cart_items);

        return count($cart_items);
    }

    /**
     * Add product with quantity.
     */
    public static function addItemsToCartWithQty($product_id, $qty = 1)
    {
        $cart_items = [];

        $product = Product::query()
            ->where('id', $product_id)
            ->first(['id', 'name', 'price', 'images']);

        if (!$product) {
            return 0;
        }

        $quantity = max(1, (int) $qty);
        $unitAmount = (float) $product->price;

        $cart_items[] = [
            'product_id' => $product->id,
            'name' => $product->name,
            'image' => self::firstProductImage($product),
            'quantity' => $quantity,
            'unit_ammount' => $unitAmount,
            'total_ammount' => $unitAmount * $quantity,
            'item_source' => 'product',
        ];

        self::addCartItemsToCookie($cart_items);

        return count($cart_items);
    }

    /**
     * Remove either a Product or Vehicle from cart.
     */
    public static function removeCartItems($item_id)
    {
        $cart_items = self::getCartItemsFromCookie();

        foreach ($cart_items as $key => $item) {
            $storedId = $item['vehicle_id']
                ?? $item['product_id']
                ?? null;

            if ((string) $storedId === (string) $item_id) {
                unset($cart_items[$key]);
            }
        }

        $cart_items = array_values($cart_items);

        self::addCartItemsToCookie($cart_items);

        return $cart_items;
    }

    /**
     * Save cart items in cookie.
     */
    public static function addCartItemsToCookie($cart_items)
    {
        Cookie::queue(
            'cart_items',
            json_encode(array_values($cart_items)),
            60 * 24 * 30
        );
    }

    /**
     * Clear cart cookie.
     */
    public static function clearCartItems($cart_items = [])
    {
        Cookie::queue(Cookie::forget('cart_items'));
    }

    /**
     * Get all cart items from cookie.
     */
    public static function getCartItemsFromCookie()
    {
        $cart_items = json_decode(
            Cookie::get('cart_items', '[]'),
            true
        );

        return is_array($cart_items) ? $cart_items : [];
    }

    /**
     * Increment Product quantity.
     *
     * Self-drive Vehicle quantity remains one because rental duration,
     * not quantity, controls its price.
     */
    public static function increamentQuntityToCartItem($item_id)
    {
        $cart_items = self::getCartItemsFromCookie();

        foreach ($cart_items as $key => $item) {
            $storedId = $item['vehicle_id']
                ?? $item['product_id']
                ?? null;

            if ((string) $storedId !== (string) $item_id) {
                continue;
            }

            if (($item['item_source'] ?? 'product') === 'vehicle') {
                continue;
            }

            $cart_items[$key]['quantity'] =
                (int) ($cart_items[$key]['quantity'] ?? 1) + 1;

            $cart_items[$key]['total_ammount'] =
                $cart_items[$key]['quantity']
                * (float) ($cart_items[$key]['unit_ammount'] ?? 0);
        }

        self::addCartItemsToCookie($cart_items);

        return $cart_items;
    }

    /**
     * Decrement Product quantity.
     */
    public static function decrementQuntityToCartItem($item_id)
    {
        $cart_items = self::getCartItemsFromCookie();

        foreach ($cart_items as $key => $item) {
            $storedId = $item['vehicle_id']
                ?? $item['product_id']
                ?? null;

            if ((string) $storedId !== (string) $item_id) {
                continue;
            }

            if (($item['item_source'] ?? 'product') === 'vehicle') {
                continue;
            }

            if ((int) ($cart_items[$key]['quantity'] ?? 1) > 1) {
                $cart_items[$key]['quantity']--;

                $cart_items[$key]['total_ammount'] =
                    $cart_items[$key]['quantity']
                    * (float) ($cart_items[$key]['unit_ammount'] ?? 0);
            }
        }

        self::addCartItemsToCookie($cart_items);

        return $cart_items;
    }

    /**
     * Calculate cart grand total.
     */
    public static function calculateGrandTotal($items)
    {
        if (!is_array($items)) {
            return 0;
        }

        return array_sum(
            array_map(
                static fn ($item) => (float) (
                    $item['total_ammount']
                    ?? $item['total_amount']
                    ?? 0
                ),
                $items
            )
        );
    }

    /**
     * Return the first Product image safely.
     */
    private static function firstProductImage($product): string
    {
        $images = $product->images ?? [];

        if (is_string($images)) {
            $decoded = json_decode($images, true);
            $images = is_array($decoded) ? $decoded : [$images];
        }

        if (!is_array($images)) {
            return '';
        }

        return (string) ($images[0] ?? '');
    }

    /**
     * Resolve Vehicle display name.
     */
    private static function vehicleDisplayName($vehicle): string
    {
        if (!empty($vehicle->display_name)) {
            return (string) $vehicle->display_name;
        }

        if (!empty($vehicle->name)) {
            return (string) $vehicle->name;
        }

        $brand = $vehicle->brand_name
            ?? $vehicle->brand
            ?? '';

        $model = $vehicle->model_name
            ?? $vehicle->model
            ?? '';

        $name = trim($brand . ' ' . $model);

        return $name !== ''
            ? $name
            : 'Self Drive Vehicle';
    }

    /**
     * Resolve Vehicle image URL/path.
     */
    private static function vehicleImage($vehicle): string
    {
        if (!empty($vehicle->front_image_url)) {
            return (string) $vehicle->front_image_url;
        }

        if (!empty($vehicle->front_image)) {
            return (string) $vehicle->front_image;
        }

        if (!empty($vehicle->image_url)) {
            return (string) $vehicle->image_url;
        }

        if (!empty($vehicle->image)) {
            return (string) $vehicle->image;
        }

        if (!empty($vehicle->images)) {
            $images = $vehicle->images;

            if (is_string($images)) {
                $decoded = json_decode($images, true);
                $images = is_array($decoded) ? $decoded : [$images];
            }

            if (is_array($images)) {
                return (string) ($images[0] ?? '');
            }
        }

        return '';
    }

    /**
     * Load whichever owner relation exists in the Vehicle model.
     */
    private static function loadVehicleOwnerRelation($vehicle): void
    {
        foreach (['transporterProfile', 'transporter', 'vendor'] as $relation) {
            if (method_exists($vehicle, $relation)) {
                $vehicle->loadMissing($relation);
                return;
            }
        }
    }

    /**
     * Resolve Vehicle vendor/transporter name.
     */
    private static function vehicleVendorName($vehicle): string
    {
        foreach (['transporterProfile', 'transporter', 'vendor'] as $relation) {
            if (!$vehicle->relationLoaded($relation)) {
                continue;
            }

            $owner = $vehicle->getRelation($relation);

            if (!$owner) {
                continue;
            }

            return (string) (
                $owner->business_name
                ?? $owner->company_name
                ?? $owner->name
                ?? ''
            );
        }

        return (string) (
            $vehicle->vendor_name
            ?? $vehicle->transporter_name
            ?? ''
        );
    }

    /**
     * Calculate chargeable rental days.
     *
     * Any partial 24-hour period is charged as a complete day.
     */
    private static function calculateRentalDays(
        $startDate,
        $endDate,
        $startTime = null,
        $endTime = null
    ): int {
        if (!$startDate || !$endDate) {
            return 1;
        }

        try {
            $start = Carbon::parse(
                trim($startDate . ' ' . ($startTime ?: '00:00:00'))
            );

            $end = Carbon::parse(
                trim($endDate . ' ' . ($endTime ?: '00:00:00'))
            );

            if ($end->lessThanOrEqualTo($start)) {
                return 1;
            }

            $minutes = $start->diffInMinutes($end);

            return max(1, (int) ceil($minutes / 1440));
        } catch (\Throwable $exception) {
            return 1;
        }
    }

    /**
     * Calculate rent using monthly, weekly and daily prices.
     */
    private static function calculateSelfDriveRent(
        int $rentalDays,
        float $dailyPrice,
        float $weeklyPrice,
        float $monthlyPrice
    ): float {
        $days = max(1, $rentalDays);
        $amount = 0.0;

        if ($monthlyPrice > 0 && $days >= 30) {
            $months = intdiv($days, 30);
            $amount += $months * $monthlyPrice;
            $days %= 30;
        }

        if ($weeklyPrice > 0 && $days >= 7) {
            $weeks = intdiv($days, 7);
            $amount += $weeks * $weeklyPrice;
            $days %= 7;
        }

        $amount += $days * $dailyPrice;

        return round($amount, 2);
    }
}