<?php

namespace App\Filament\Resources;

use App\Filament\Resources\FleetResource\Pages;
use App\Models\FleetManagement\Fleet;
use App\Models\FleetManagement\TransporterProfile;
use Filament\Forms\Form;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Illuminate\Support\Str;

class FleetResource extends Resource
{
    protected static ?string $model = Fleet::class;

    protected static ?string $navigationIcon = 'heroicon-o-truck';
    protected static ?string $navigationGroup = 'Fleet Management';
    protected static ?string $navigationLabel = 'Fleet';
    protected static ?string $modelLabel = 'Fleet';
    protected static ?string $pluralModelLabel = 'Fleet';
    protected static ?int $navigationSort = 1;

    public static function form(Form $form): Form
    {
        return $form->schema([

            Section::make('Fleet Information')
                ->schema([
                    Select::make('transporter_profile_id')
                        ->label('Transporter / Vendor')
                        ->options(function () {
                            return TransporterProfile::query()
                                ->where('status', true)
                                ->orderBy('company_name')
                                ->get()
                                ->mapWithKeys(function ($profile) {
                                    $company = $profile->company_name ?: 'No Company';
                                    $person = $profile->contact_person ?: 'No Contact';
                                    $mobile = $profile->mobile ?: 'No Mobile';
                                    $city = $profile->city ?: 'No City';

                                    return [
                                        $profile->id => "{$company} | {$person} | {$mobile} | {$city}",
                                    ];
                                });
                        })
                        ->searchable()
                        ->preload()
                        ->required(),

                    Select::make('vehicle_type')
                        ->label('Vehicle Type')
                        ->options([
                            'car' => 'Car',
                            'bike' => 'Bike',
                        ])
                        ->default('car')
                        ->required(),

                    TextInput::make('name')
                        ->label('Brand / Model Name')
                        ->required()
                        ->maxLength(180)
                        ->live(onBlur: true)
                        ->afterStateUpdated(fn ($state, callable $set) => $set('slug', Str::slug($state))),

                    TextInput::make('slug')
                        ->required()
                        ->maxLength(220)
                        ->unique(ignoreRecord: true),

                    FileUpload::make('image')
                        ->label('Main Image')
                        ->image()
                        ->directory('fleet/main')
                        ->imageEditor(),
                ])
                ->columns(2),

            Section::make('Vehicle Details')
                ->schema([
                    TextInput::make('model_similar')
                        ->label('Model / Similar Cars'),

                    Select::make('fuel_type')
                        ->label('Fuel Type')
                        ->options([
                            'petrol' => 'Petrol',
                            'diesel' => 'Diesel',
                            'cng' => 'CNG',
                            'petrol_cng' => 'Petrol + CNG',
                            'electric' => 'Electric',
                            'hybrid' => 'Hybrid',
                        ]),

                    Select::make('transmission')
                        ->label('Transmission')
                        ->options([
                            'manual' => 'Manual',
                            'automatic' => 'Automatic',
                            'amt' => 'AMT',
                            'cvt' => 'CVT',
                        ]),

                    TextInput::make('passenger_capacity')
                        ->label('Passenger Capacity')
                        ->placeholder('4+1'),

                    TextInput::make('luggage_capacity')
                        ->label('Luggage Capacity'),

                    TextInput::make('range_km')
                        ->label('Range')
                        ->numeric()
                        ->suffix('KM'),

                    Toggle::make('sun_roof')
                        ->label('Sun Roof'),

                    Toggle::make('gps')
                        ->label('GPS'),
                ])
                ->columns(2),

            Section::make('Vehicle Information')
                ->schema([
                    TextInput::make('vehicle_number')
                        ->label('Vehicle Number'),

                    TextInput::make('chassis_number')
                        ->label('Chassis Number'),

                    TextInput::make('engine_number')
                        ->label('Engine Number'),

                    TextInput::make('owner_name')
                        ->label('Owner Name'),

                    TextInput::make('car_color')
                        ->label('Car Color'),

                    FileUpload::make('photo_left')
                        ->label('Left Photo')
                        ->image()
                        ->directory('fleet/photos'),

                    FileUpload::make('photo_right')
                        ->label('Right Photo')
                        ->image()
                        ->directory('fleet/photos'),

                    FileUpload::make('photo_front')
                        ->label('Front Photo')
                        ->image()
                        ->directory('fleet/photos'),

                    FileUpload::make('photo_back')
                        ->label('Back Photo')
                        ->image()
                        ->directory('fleet/photos'),

                    FileUpload::make('photo_interior')
                        ->label('Interior Photo')
                        ->image()
                        ->directory('fleet/photos'),

                    FileUpload::make('rc_image')
                        ->label('RC Image')
                        ->image()
                        ->directory('fleet/documents/rc'),

                    FileUpload::make('insurance_image')
                        ->label('Insurance Image')
                        ->image()
                        ->directory('fleet/documents/insurance'),

                    FileUpload::make('pollution_image')
                        ->label('Pollution Image')
                        ->image()
                        ->directory('fleet/documents/pollution'),
                ])
                ->columns(2),

            Section::make('Pricing & Charges')
                ->schema([
                    TextInput::make('km_charge')
                        ->label('KM Charge')
                        ->numeric()
                        ->prefix('₹')
                        ->default(0),

                    TextInput::make('hour_charge')
                        ->label('Hour Charge')
                        ->numeric()
                        ->prefix('₹')
                        ->default(0),

                    TextInput::make('weekly_charge')
                        ->label('Weekly Charge')
                        ->numeric()
                        ->prefix('₹')
                        ->default(0),

                    TextInput::make('monthly_charge')
                        ->label('Monthly Charge')
                        ->numeric()
                        ->prefix('₹')
                        ->default(0),

                    TextInput::make('security_deposit')
                        ->label('Security Deposit')
                        ->numeric()
                        ->prefix('₹')
                        ->default(0),
                ])
                ->columns(3),

            Section::make('Status')
                ->schema([
                    Select::make('status')
                        ->label('Active / Not Active')
                        ->options([
                            'active' => 'Active',
                            'inactive' => 'Not Active',
                        ])
                        ->default('active')
                        ->required(),
                ])
                ->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                ImageColumn::make('image')
                    ->label('Image')
                    ->square(),

                TextColumn::make('transporter.company_name')
                    ->label('Transporter')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('name')
                    ->label('Fleet')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('vehicle_type')
                    ->label('Type')
                    ->badge(),

                TextColumn::make('vehicle_number')
                    ->label('Vehicle No.')
                    ->searchable(),

                TextColumn::make('km_charge')
                    ->label('KM Charge')
                    ->money('INR'),

                TextColumn::make('status')
                    ->badge()
                    ->sortable(),

                TextColumn::make('created_at')
                    ->label('Created')
                    ->dateTime('d M Y'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListFleets::route('/'),
            'create' => Pages\CreateFleet::route('/create'),
            'edit' => Pages\EditFleet::route('/{record}/edit'),
        ];
    }
}