<?php

namespace App\Filament\Resources\BrandResource\Pages;

use App\Filament\Resources\BrandResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListBrands extends ListRecords
{
    protected static string $resource = BrandResource::class;

    protected static ?string $title = 'Manage City';
    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make()->label('New City'),
        ];
    }
}
