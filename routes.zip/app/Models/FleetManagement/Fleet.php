<?php

namespace App\Models\FleetManagement;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Fleet extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'fleets';

    protected $fillable = [
        'uuid',
        'transporter_profile_id',
        'vehicle_type',
        'name',
        'slug',
        'image',
        'model_similar',
        'fuel_type',
        'transmission',
        'passenger_capacity',
        'luggage_capacity',
        'range_km',
        'sun_roof',
        'gps',
        'vehicle_number',
        'chassis_number',
        'engine_number',
        'owner_name',
        'car_color',
        'photo_left',
        'photo_right',
        'photo_front',
        'photo_back',
        'photo_interior',
        'rc_image',
        'insurance_image',
        'pollution_image',
        'km_charge',
        'hour_charge',
        'weekly_charge',
        'monthly_charge',
        'security_deposit',
        'status',
    ];

    protected $casts = [
        'range_km' => 'decimal:2',
        'sun_roof' => 'boolean',
        'gps' => 'boolean',
        'km_charge' => 'decimal:2',
        'hour_charge' => 'decimal:2',
        'weekly_charge' => 'decimal:2',
        'monthly_charge' => 'decimal:2',
        'security_deposit' => 'decimal:2',
    ];

    public function transporter(): BelongsTo
    {
        return $this->belongsTo(
            TransporterProfile::class,
            'transporter_profile_id'
        );
    }
}