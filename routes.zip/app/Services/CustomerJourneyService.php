<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\CustomerSearchActivity;
use App\Services\CustomerJourneyService;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Throwable;

class CustomerJourneyController extends Controller
{
    public function __construct(
        private readonly CustomerJourneyService $customerJourneyService
    ) {
    }

    /**
     * Register a customer search event.
     *
     * POST /api/v1/customer-journey/search-performed
     */
    public function searchPerformed(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'search_activity_id' => [
                    'nullable',
                    'integer',
                    'exists:customer_search_activities,id',
                ],

                'search_activity_uuid' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'search_data' => [
                    'nullable',
                    'array',
                ],

                'search_data.*' => [
                    'nullable',
                ],
            ]);

            $activity = $this->resolveActivity($validated);

            $this->customerJourneyService->searchPerformed(
                searchActivity: $activity,
                searchData: $validated['search_data'] ?? []
            );

            return $this->successResponse(
                message: 'Search activity recorded successfully.',
                activity: $activity
            );
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (ModelNotFoundException $exception) {
            return $this->notFoundResponse();
        } catch (Throwable $exception) {
            return $this->errorResponse(
                action: 'search_performed',
                exception: $exception
            );
        }
    }

    /**
     * Register checkout-started event.
     *
     * POST /api/v1/customer-journey/checkout-started
     */
    public function checkoutStarted(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'search_activity_id' => [
                    'nullable',
                    'integer',
                    'exists:customer_search_activities,id',
                ],

                'search_activity_uuid' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'checkout_data' => [
                    'nullable',
                    'array',
                ],

                'checkout_data.vehicle_id' => [
                    'nullable',
                    'integer',
                ],

                'checkout_data.vehicle_category_id' => [
                    'nullable',
                    'integer',
                ],

                'checkout_data.vehicle_name' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'checkout_data.vehicle_category_name' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'checkout_data.vehicle_type' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'checkout_data.plan_type' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'checkout_data.plan_name' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'checkout_data.estimated_amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'checkout_data.grand_total' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'checkout_data.base_fare' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'checkout_data.discount_amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'checkout_data.coupon_code' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'checkout_data.coupon_discount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'checkout_data.currency' => [
                    'nullable',
                    'string',
                    'max:10',
                ],

                'checkout_data.security_deposit' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'checkout_data.is_all_inclusive' => [
                    'nullable',
                    'boolean',
                ],

                'checkout_data.fare_breakdown' => [
                    'nullable',
                    'array',
                ],

                'checkout_data.metadata' => [
                    'nullable',
                    'array',
                ],
            ]);

            $activity = $this->resolveActivity($validated);

            $this->customerJourneyService->checkoutStarted(
                searchActivity: $activity,
                checkoutData: $validated['checkout_data'] ?? []
            );

            return $this->successResponse(
                message: 'Checkout activity recorded successfully.',
                activity: $activity
            );
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (ModelNotFoundException $exception) {
            return $this->notFoundResponse();
        } catch (Throwable $exception) {
            return $this->errorResponse(
                action: 'checkout_started',
                exception: $exception
            );
        }
    }

    /**
     * Register payment-started event.
     *
     * POST /api/v1/customer-journey/payment-started
     */
    public function paymentStarted(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'search_activity_id' => [
                    'nullable',
                    'integer',
                    'exists:customer_search_activities,id',
                ],

                'search_activity_uuid' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'payment_data' => [
                    'required',
                    'array',
                ],

                'payment_data.amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'payment_data.grand_total' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'payment_data.payment_method' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'payment_data.gateway' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'payment_data.currency' => [
                    'nullable',
                    'string',
                    'max:10',
                ],

                'payment_data.order_id' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.gateway_order_id' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.transaction_id' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.metadata' => [
                    'nullable',
                    'array',
                ],
            ]);

            $activity = $this->resolveActivity($validated);

            $this->customerJourneyService->paymentStarted(
                searchActivity: $activity,
                paymentData: $validated['payment_data']
            );

            return $this->successResponse(
                message: 'Payment-started activity recorded successfully.',
                activity: $activity
            );
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (ModelNotFoundException $exception) {
            return $this->notFoundResponse();
        } catch (Throwable $exception) {
            return $this->errorResponse(
                action: 'payment_started',
                exception: $exception
            );
        }
    }

    /**
     * Register successful payment and booking conversion.
     *
     * POST /api/v1/customer-journey/payment-succeeded
     */
    public function paymentSucceeded(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'search_activity_id' => [
                    'nullable',
                    'integer',
                    'exists:customer_search_activities,id',
                ],

                'search_activity_uuid' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'payment_data' => [
                    'required',
                    'array',
                ],

                'payment_data.amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'payment_data.paid_amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'payment_data.grand_total' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'payment_data.payment_method' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'payment_data.gateway' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'payment_data.currency' => [
                    'nullable',
                    'string',
                    'max:10',
                ],

                'payment_data.transaction_id' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.gateway_payment_id' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.gateway_order_id' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.gateway_signature' => [
                    'nullable',
                    'string',
                    'max:1000',
                ],

                'payment_data.status' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'payment_data.metadata' => [
                    'nullable',
                    'array',
                ],

                'booking_data' => [
                    'required',
                    'array',
                ],

                'booking_data.booking_id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.booking_no' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'booking_data.booking_number' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'booking_data.status' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.service_type' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.trip_type' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.total_amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'booking_data.paid_amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'booking_data.metadata' => [
                    'nullable',
                    'array',
                ],
            ]);

            $activity = $this->resolveActivity($validated);

            $this->customerJourneyService->paymentSucceeded(
                searchActivity: $activity,
                paymentData: $validated['payment_data'],
                bookingData: $validated['booking_data']
            );

            return $this->successResponse(
                message: 'Successful payment activity recorded.',
                activity: $activity
            );
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (ModelNotFoundException $exception) {
            return $this->notFoundResponse();
        } catch (Throwable $exception) {
            return $this->errorResponse(
                action: 'payment_succeeded',
                exception: $exception
            );
        }
    }

    /**
     * Register failed payment.
     *
     * POST /api/v1/customer-journey/payment-failed
     */
    public function paymentFailed(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'search_activity_id' => [
                    'nullable',
                    'integer',
                    'exists:customer_search_activities,id',
                ],

                'search_activity_uuid' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'reason' => [
                    'nullable',
                    'string',
                    'max:1000',
                ],

                'payment_data' => [
                    'required',
                    'array',
                ],

                'payment_data.amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'payment_data.grand_total' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'payment_data.payment_method' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'payment_data.gateway' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'payment_data.currency' => [
                    'nullable',
                    'string',
                    'max:10',
                ],

                'payment_data.transaction_id' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.gateway_payment_id' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.gateway_order_id' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.error_code' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'payment_data.error_message' => [
                    'nullable',
                    'string',
                    'max:1000',
                ],

                'payment_data.can_retry' => [
                    'nullable',
                    'boolean',
                ],

                'payment_data.metadata' => [
                    'nullable',
                    'array',
                ],
            ]);

            $activity = $this->resolveActivity($validated);

            $this->customerJourneyService->paymentFailed(
                searchActivity: $activity,
                paymentData: $validated['payment_data'],
                reason: $validated['reason'] ?? null
            );

            return $this->successResponse(
                message: 'Failed payment activity recorded.',
                activity: $activity
            );
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (ModelNotFoundException $exception) {
            return $this->notFoundResponse();
        } catch (Throwable $exception) {
            return $this->errorResponse(
                action: 'payment_failed',
                exception: $exception
            );
        }
    }

    /**
     * Register booking completion.
     *
     * POST /api/v1/customer-journey/booking-completed
     */
    public function bookingCompleted(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'search_activity_id' => [
                    'nullable',
                    'integer',
                    'exists:customer_search_activities,id',
                ],

                'search_activity_uuid' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data' => [
                    'required',
                    'array',
                ],

                'booking_data.booking_id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.booking_no' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'booking_data.booking_number' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'booking_data.status' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.service_type' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.trip_type' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.vehicle_id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.driver_id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.customer_id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.transporter_id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.total_amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'booking_data.paid_amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'booking_data.balance_amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'booking_data.completed_at' => [
                    'nullable',
                    'date',
                ],

                'booking_data.metadata' => [
                    'nullable',
                    'array',
                ],
            ]);

            $activity = $this->resolveActivity($validated);

            $this->customerJourneyService->bookingCompleted(
                searchActivity: $activity,
                bookingData: $validated['booking_data']
            );

            return $this->successResponse(
                message: 'Booking completion activity recorded.',
                activity: $activity
            );
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (ModelNotFoundException $exception) {
            return $this->notFoundResponse();
        } catch (Throwable $exception) {
            return $this->errorResponse(
                action: 'booking_completed',
                exception: $exception
            );
        }
    }

    /**
     * Register booking cancellation.
     *
     * POST /api/v1/customer-journey/booking-cancelled
     */
    public function bookingCancelled(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'search_activity_id' => [
                    'nullable',
                    'integer',
                    'exists:customer_search_activities,id',
                ],

                'search_activity_uuid' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'reason' => [
                    'nullable',
                    'string',
                    'max:1000',
                ],

                'booking_data' => [
                    'required',
                    'array',
                ],

                'booking_data.booking_id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.id' => [
                    'nullable',
                    'integer',
                ],

                'booking_data.booking_no' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'booking_data.booking_number' => [
                    'nullable',
                    'string',
                    'max:255',
                ],

                'booking_data.status' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.refund_amount' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'booking_data.refund_status' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.cancellation_charge' => [
                    'nullable',
                    'numeric',
                    'min:0',
                ],

                'booking_data.cancelled_by' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.cancellation_type' => [
                    'nullable',
                    'string',
                    'max:100',
                ],

                'booking_data.cancelled_at' => [
                    'nullable',
                    'date',
                ],

                'booking_data.metadata' => [
                    'nullable',
                    'array',
                ],
            ]);

            $activity = $this->resolveActivity($validated);

            $this->customerJourneyService->bookingCancelled(
                searchActivity: $activity,
                bookingData: $validated['booking_data'],
                reason: $validated['reason'] ?? null
            );

            return $this->successResponse(
                message: 'Booking cancellation activity recorded.',
                activity: $activity
            );
        } catch (ValidationException $exception) {
            throw $exception;
        } catch (ModelNotFoundException $exception) {
            return $this->notFoundResponse();
        } catch (Throwable $exception) {
            return $this->errorResponse(
                action: 'booking_cancelled',
                exception: $exception
            );
        }
    }

    /**
     * Fetch one customer journey activity.
     *
     * GET /api/v1/customer-journey/{identifier}
     */
    public function show(int|string $identifier): JsonResponse
    {
        try {
            $activity = $this->customerJourneyService
                ->findActivityOrFail($identifier);

            return response()->json([
                'status' => true,
                'message' => 'Customer journey activity fetched successfully.',
                'data' => [
                    'activity' => $activity,
                ],
            ]);
        } catch (ModelNotFoundException $exception) {
            return $this->notFoundResponse();
        } catch (Throwable $exception) {
            return $this->errorResponse(
                action: 'show_customer_journey',
                exception: $exception
            );
        }
    }

    /**
     * Resolve activity using ID or UUID.
     */
    private function resolveActivity(array $validated): CustomerSearchActivity
    {
        $activityId = $validated['search_activity_id'] ?? null;
        $activityUuid = trim(
            (string) ($validated['search_activity_uuid'] ?? '')
        );

        if ($activityId !== null) {
            return CustomerSearchActivity::query()
                ->findOrFail((int) $activityId);
        }

        if ($activityUuid !== '') {
            return CustomerSearchActivity::query()
                ->where('uuid', $activityUuid)
                ->firstOrFail();
        }

        throw ValidationException::withMessages([
            'search_activity_id' => [
                'Search activity ID or search activity UUID is required.',
            ],
            'search_activity_uuid' => [
                'Search activity UUID or search activity ID is required.',
            ],
        ]);
    }

    /**
     * Standard successful response.
     */
    private function successResponse(
        string $message,
        CustomerSearchActivity $activity
    ): JsonResponse {
        $freshActivity = $activity->fresh() ?? $activity;

        return response()->json([
            'status' => true,
            'message' => $message,
            'data' => [
                'search_activity_id' => $freshActivity->id,
                'search_activity_uuid' => $freshActivity->uuid,
                'activity' => $freshActivity,
            ],
        ]);
    }

    /**
     * Standard record-not-found response.
     */
    private function notFoundResponse(): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => 'Customer search activity not found.',
            'data' => null,
        ], 404);
    }

    /**
     * Log and return unexpected errors.
     */
    private function errorResponse(
        string $action,
        Throwable $exception
    ): JsonResponse {
        Log::error('CustomerJourneyController request failed.', [
            'action' => $action,
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
        ]);

        return response()->json([
            'status' => false,
            'message' => app()->isProduction()
                ? 'Unable to process customer journey activity.'
                : $exception->getMessage(),
            'data' => null,
        ], 500);
    }
}