<div class="lg:mx-10 mx-2 my-4">
    <div class="px-10 py-5 bg-white shadow-2xl shadow-slate-400 flex gap-4 justify-start items-center">
       <a href="/">
        <svg class="w-5 h-5 " fill="#1e9cfd" xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
            <path
                d="M543.8 287.6c17 0 32-14 32-32.1c1-9-3-17-11-24L512 185l0-121c0-17.7-14.3-32-32-32l-32 0c-17.7 0-32 14.3-32 32l0 36.7L309.5 7c-6-5-14-7-21-7s-15 1-22 8L10 231.5c-7 7-10 15-10 24c0 18 14 32.1 32 32.1l32 0 0 69.7c-.1 .9-.1 1.8-.1 2.8l0 112c0 22.1 17.9 40 40 40l16 0c1.2 0 2.4-.1 3.6-.2c1.5 .1 3 .2 4.5 .2l31.9 0 24 0c22.1 0 40-17.9 40-40l0-24 0-64c0-17.7 14.3-32 32-32l64 0c17.7 0 32 14.3 32 32l0 64 0 24c0 22.1 17.9 40 40 40l24 0 32.5 0c1.4 0 2.8 0 4.2-.1c1.1 .1 2.2 .1 3.3 .1l16 0c22.1 0 40-17.9 40-40l0-16.2c.3-2.6 .5-5.3 .5-8.1l-.7-160.2 32 0z" />
        </svg> 
       </a>
        <h2 class="text-xl ">/about-us</h2>
    </div>
    <div class="p-10 mt-2 bg-white shadow-2xl shadow-slate-400">
        <h1 class="lg:text-4xl text-xl font-extrabold text-center">About Us</h1>
    </div>
    <div class="lg:flex grid lg:p-2 pt-2">
        <div class="md:m-2 p-2 lg:w-1/3 w-full bg-white shadow-2xl shadow-slate-400">
            <h2 class="lg:text-4xl text-xl main-color-text">Topies</h2>
            <a href="#expect" class="flex gap-2 mt-2 ms-4 ">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#1e9cfd" class="w-6 h-6"
                    viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                    <path
                        d="M480 96c17.7 0 32 14.3 32 32s-14.3 32-32 32l-208 0 0-64 208 0zM320 288c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0zm64-64c0 17.7-14.3 32-32 32l-48 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l48 0c17.7 0 32 14.3 32 32zM288 384c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0zm-88-96l.6 0c-5.4 9.4-8.6 20.3-8.6 32c0 13.2 4 25.4 10.8 35.6C177.9 364.3 160 388.1 160 416c0 11.7 3.1 22.6 8.6 32l-8.6 0C71.6 448 0 376.4 0 288l0-61.7c0-42.4 16.9-83.1 46.9-113.1l11.6-11.6C82.5 77.5 115.1 64 149 64l27 0c35.3 0 64 28.7 64 64l0 88c0 22.1-17.9 40-40 40s-40-17.9-40-40l0-56c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 56c0 39.8 32.2 72 72 72z" />
                </svg>
                <p class="main-color-text">What can you expect from Duracabs?</p>
            </a>
            <a href="#sanitized" class="flex gap-2 mt-4 ms-4  ">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#1e9cfd" class="w-6 h-6"
                    viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                    <path
                        d="M480 96c17.7 0 32 14.3 32 32s-14.3 32-32 32l-208 0 0-64 208 0zM320 288c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0zm64-64c0 17.7-14.3 32-32 32l-48 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l48 0c17.7 0 32 14.3 32 32zM288 384c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0zm-88-96l.6 0c-5.4 9.4-8.6 20.3-8.6 32c0 13.2 4 25.4 10.8 35.6C177.9 364.3 160 388.1 160 416c0 11.7 3.1 22.6 8.6 32l-8.6 0C71.6 448 0 376.4 0 288l0-61.7c0-42.4 16.9-83.1 46.9-113.1l11.6-11.6C82.5 77.5 115.1 64 149 64l27 0c35.3 0 64 28.7 64 64l0 88c0 22.1-17.9 40-40 40s-40-17.9-40-40l0-56c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 56c0 39.8 32.2 72 72 72z" />
                </svg>
                <p class="main-color-text"> Safe And Sanitized Car</p>
            </a>
            <a href="#rent" class="flex gap-2 mt-4 ms-4 ">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#1e9cfd" class="w-6 h-6"
                    viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                    <path
                        d="M480 96c17.7 0 32 14.3 32 32s-14.3 32-32 32l-208 0 0-64 208 0zM320 288c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0zm64-64c0 17.7-14.3 32-32 32l-48 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l48 0c17.7 0 32 14.3 32 32zM288 384c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0zm-88-96l.6 0c-5.4 9.4-8.6 20.3-8.6 32c0 13.2 4 25.4 10.8 35.6C177.9 364.3 160 388.1 160 416c0 11.7 3.1 22.6 8.6 32l-8.6 0C71.6 448 0 376.4 0 288l0-61.7c0-42.4 16.9-83.1 46.9-113.1l11.6-11.6C82.5 77.5 115.1 64 149 64l27 0c35.3 0 64 28.7 64 64l0 88c0 22.1-17.9 40-40 40s-40-17.9-40-40l0-56c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 56c0 39.8 32.2 72 72 72z" />
                </svg>
                <p class="main-color-text">Self-Drive Car On Rent </p>
            </a>

            <a href="#team" class="flex gap-2 mt-4 ms-4 ">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#1e9cfd" class="w-6 h-6"
                    viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                    <path
                        d="M480 96c17.7 0 32 14.3 32 32s-14.3 32-32 32l-208 0 0-64 208 0zM320 288c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0zm64-64c0 17.7-14.3 32-32 32l-48 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l48 0c17.7 0 32 14.3 32 32zM288 384c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0zm-88-96l.6 0c-5.4 9.4-8.6 20.3-8.6 32c0 13.2 4 25.4 10.8 35.6C177.9 364.3 160 388.1 160 416c0 11.7 3.1 22.6 8.6 32l-8.6 0C71.6 448 0 376.4 0 288l0-61.7c0-42.4 16.9-83.1 46.9-113.1l11.6-11.6C82.5 77.5 115.1 64 149 64l27 0c35.3 0 64 28.7 64 64l0 88c0 22.1-17.9 40-40 40s-40-17.9-40-40l0-56c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 56c0 39.8 32.2 72 72 72z" />
                </svg>
                <p class="main-color-text">Our Team </p>
            </a>
        </div>

        <div class="w-full">
            <div class="lg:m-2 mt-2 p-4 bg-white shadow-2xl shadow-slate-400 text-justify">
                <p>
                    DURA Cabs Services is a complete car rental solution for Local Taxi Services, Outstation Taxi With
                    Driver & Holidays Tour Package In India. Within few years of its launch, DURACABS has positioned
                    itself as India’s National Chauffeur company with dedicated offices in every major city., With over
                    110000 + taxis operating across 390+ cities the We have several exciting offerings lined up, the
                    most prominent being 'Package Offers' to key tourist and buisness destinations. Our portal allows
                    customers to check the availability of taxis in real time and make customized itinerary-based
                    bookings We Provide Best Taxi Service Provider in Agra/Delhi/Jaipur / Chandigarh / Shimla.
                </p>

                <h2 class="text-xl main-color-text bg-gray-100 p-4 mt-4 scroll-mt-20" id="expect">
                    What can you expect from Duracabs?
                </h2>

                <p>
                    At Duracabs you can expect customer support and a friendly and helpful attitude of the drivers. They
                    have a positive outlook and will help you create a great itinerary that you can follow on your
                    journey. Whenever you choose to book a car online from our website, your booking starts within few
                    minutes without any advance payment. You can enter your pickup location and drop-off location from
                    the website and set the date on which you wish to leave for the trip. Our best drivers will arrive
                    at your doorstep to pick you up and your family without any delay. The drivers of Duracabs always
                    maintain a strict uniform code and are highly trained to drive any vehicle you choose.
                </p>
            </div>

            <div class="lg:m-2 mt-2 p-4 bg-white shadow-2xl shadow-slate-400 text-justify scroll-mt-20" id="sanitized">
                <h2 class="text-xl main-color-text bg-gray-100 p-4 mt-4">
                    DuraCabs: Safe And Sanitized Car On Rent
                </h2>
                <p>
                    Subscribing to Duracabs gives you the flexibility to own the car at any time, while also assuring
                    you of a clean and virus-free vehicle for your own drive. The car sanitization process incorporates
                    all preventive hygiene best practices as directed by the World Health Organization (WHO) and is
                    diligently conducted for each vehicle delivered to the car customers. The security measures
                    implemented include: Industrial standard for all vehicle surfaces Sanitation and disinfection prior
                    to delivery
                </p>
            </div>

            <div class="lg:m-2 mt-2 p-4 bg-white shadow-2xl shadow-slate-400 text-justify scroll-mt-20" id="rent">
                <h2 class="text-xl main-color-text bg-gray-100 p-4 mt-4">
                    Self-Drive Car On Rent
                </h2>
                <p>
                    Self drive car rental services are a convenient way to get around without using your vehicle or
                    resorting to public transportation. We have it for you to explore a city, take a much needed road
                    trip and make an easy getaway possible by renting a car like scooter, motorcycle, car jeep. Gone are
                    the days when owning a car was a must. It is very easy and very cheap to hire Dura Cabs Self Drive
                    Car Rental Services. With Dura Cab you get all the mobility and privacy you need.
                </p>
            </div>

            <div class="lg:m-2 mt-2 p-4 bg-white shadow-2xl shadow-slate-400 text-justify scroll-mt-20" id="team">
                <h2 class="text-xl main-color-text bg-gray-100 p-4 mt-4">
                    Our Team
                </h2>
                <p>
                    That's what everyone says, but in our case it's true: The secret to our success is our team. Each of
                    our employees is wonderful in their own right, but together they are what make DuraCabs such a fun
                    and rewarding place to work. The Duracabs team is an agile, talented group with a shared vision of
                    consistently delivering great results for our clients, while ensuring that the agency is a fun,
                    place to work and develop a rewarding career.
                </p>

                <p class="mt-2">
                    We're very proud of the team we've built - there are over thirty of us now but it still feels like
                    there were only a few of us. Duracabs has always been an agency defined by bringing together
                    talented people with a shared vision and passion so that we can be the best for our clients . All of
                    our employees are unique individuals united by a set of five core values that apply to everything we
                    do within the agency.
                </p>
            </div>
        </div>

    </div>
</div>
