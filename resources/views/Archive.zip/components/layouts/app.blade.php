<!DOCTYPE html>
<html  class="scroll-smooth focus:scroll-auto">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <link rel="icon" type="image/x-icon" href="/img/logo/favicon_duracabs.svg">


    <link rel="stylesheet" href="https://unpkg.com/swiper@6.8.4/swiper-bundle.min.css">


    @livewireStyles

    <title>@yield('title') : {{config('app.name', 'Dura Cabs')}}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <meta name="description" content="@yield('description')" />
    <link rel="canonical" href="https://www.duracabs.com">
    <meta name='robots' content='index, follow' />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <meta name="author" content="duracabs">
    <meta name="zipcode" content="282001">
    <meta name="abstract" content="@yield('title')">
    <meta name="contact" content="+91-7088873332">
    <meta name="city" content="Agra">
    <meta name="country" content="India">
    <meta name="generator" content="">
    <meta name="reply-to" content="info@duracabs.com">
    <meta name="copyright" content="Duracabs.com" />
    <meta name="web_content_type" content="@yield('title')" />
    <meta name="classification" content="" />
    <meta name="contactName" content="Duracabs Service" />
    <meta name="contactOrganization" content="duracabs" />
    <meta name="contactNetworkAddress" content="Agra, Uttar Pradesh" />

    <!--og-tags-->
    <meta property="og:site_name" content="Duracabs" />
    <meta property="og:type" content="Transportations" />
    <meta property="og:title" content="@yield('title')" />
    <meta property="og:description"
        content="@yield('description')" />
    <meta property="og:url" content="https://www.duracabs.com" />
    <meta property="og:image" content="@yield('image')" />

    <meta name="p:domain_verify" content="259d6abf77e85d24ce8d289b1d2c2b64" />
    <meta name="yandex-verification" content="df32f3caa9d74bb4" />

    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@duracabs" />
    <meta property="twitter:description"
        content="@yield('description')" />
    <meta name="twitter:title" content="@yield('title') Dura Cabs" />
    <meta name="twitter:image" content="@yield('image')" />

</head>

<body class="bg-white dark:bg-slate-700">


    @livewire('partials.navbar')
    <main>
        {{ $slot }}
    </main>
    @livewire('partials.footer')
    @livewireScripts
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/swiper@6.8.4/swiper-bundle.min.js"></script>


</body>

</html>
