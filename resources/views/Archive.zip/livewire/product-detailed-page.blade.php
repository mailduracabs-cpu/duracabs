<div class="w-full max-w-[85rem] lg:px-10 px-4 mt-2  mx-auto">

    @if ($tab === 'one_way')
        <div class="fixed  z-50 inset-0 bg-gray-900 bg-opacity-60 overflow-y-auto h-full w-full px-4 ">
            <div class="relative top-40 mx-auto shadow-xl rounded-md bg-white max-w-md">


                <form
                    wire:submit.prevent='submitOneWay([{{ $ride->id }},"{{ $time }}","{{ $tab }}","{{ $date }}","{{$price}}","{{$name}}", "{{$categoryName}}"])'>
                    <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                        <div class="flex">

                            <div class="mt-3 w-full text-center sm:ml-4 sm:mt-0 sm:text-left">
                                <h3 class="text-2xl text-center font-semibold leading-6 text-gray-900" id="modal-title">
                                    Pickup Details
                                </h3>
                                <div class="mt-2 w-full">

                                    <div class="">
                                        <label for="" class="font-semibold">PickUp Date</label>
                                        <input type="date" wire:model.live='date' maxlength="4" placeholder="date"
                                            required
                                            class=" bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                                    </div>
                                    <div class="mt-3">
                                        <label for="" class="font-semibold">PickUp Time</label>
                                        <input type="time" wire:model.live='time' maxlength="4" placeholder="time"
                                            required
                                            class=" bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                                    </div>

                                    <button type='submit'
                                        class="main-color mt-4 text-xl w-full text-white p-2 rounded-sm">
                                        Book Now
                                    </button>




                                </div>
                            </div>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    @endif

    @if ($tab === 'local')
        <div class="fixed  z-50 inset-0 bg-gray-900 bg-opacity-60 overflow-y-auto h-full w-full px-4 ">
            <div class="relative top-40 mx-auto shadow-xl rounded-md bg-white max-w-md">

                <form
                    wire:submit.prevent='submitLocal([{{ $ride->id }},"{{ $time }}","{{ $tab }}","{{ $date }}","{{ $plan }}","{{ 1 }}"])'>
                    <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                        <div class="flex">

                            <div class="mt-3 w-full text-center sm:ml-4 sm:mt-0 sm:text-left">
                                <h3 class="text-2xl text-center font-semibold leading-6 text-gray-900" id="modal-title">
                                    Pickup Details
                                </h3>
                                <div class="mt-2 w-full">

                                    <div class="">
                                        <label class="font-semibold" for="">PickUp Date</label>
                                        <input type="date" wire:model.live='date' maxlength="4" placeholder="date"
                                            required
                                            class=" bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                                    </div>
                                    <div class="mt-3">
                                        <label class="font-semibold" for="">PickUp Time</label>
                                        <input type="time" wire:model.live='time' maxlength="4" placeholder="time"
                                            required
                                            class=" bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                                    </div>
                                    <div class="mt-3">
                                        {{ $plan }}
                                        <label class="font-semibold" for="">Select Plans</label>
                                        <select wire:model.live='plan' name="plan" id="plan" required
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                            <option value="4 Hour / 40 Km">4 Hour / 40 Km</option>
                                            <option value="8 Hour / 80 Km">8 Hour / 80 Km</option>
                                            <option value="12 Hour / 120 Km">12 Hour / 120 Km</option>
                                        </select>
                                    </div>
                                    <button type="submit"
                                        class="main-color mt-4 text-xl w-full text-white p-2 rounded-sm">
                                        Book Now
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    @endif

    @if ($tab === 'self_drive')
        <div class="fixed  z-50 inset-0 bg-gray-900 bg-opacity-60 overflow-y-auto h-full w-full px-4 ">
            <div class="relative top-40 mx-auto shadow-xl rounded-md bg-white max-w-md">

                <form
                    wire:submit.prevent='submitSelfDrive([{{ $ride->id }},"{{ $time }}","{{ $endTime }}","{{ $tab }}","{{ $date }}","{{ $endDate }}",{{ $ride->price * $hours }}])'>
                    <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                        <div class="flex">

                            <div class="mt-3 w-full text-center sm:ml-4 sm:mt-0 sm:text-left">
                                <h3 class="text-2xl text-center font-semibold leading-6 text-gray-900" id="modal-title">
                                    Pickup Details
                                </h3>
                                <div class="mt-2 w-full">

                                    <div class="">
                                        <label class="font-semibold" for="">PickUp Date</label>
                                        <input type="date" wire:model.live='date' maxlength="4" placeholder="date"
                                            required
                                            class=" bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                                    </div>
                                    <div class="mt-3">
                                        <label class="font-semibold" for="">PickUp Time</label>
                                        <input type="time" wire:model.live='time' maxlength="4" placeholder="time"
                                            required
                                            class=" bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                                    </div>


                                    <div class="">
                                        <label class="font-semibold" for="">Drop Date</label>
                                        <input type="date" wire:model.live='endDate' maxlength="4"
                                            placeholder="date" required
                                            class=" bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                                    </div>

                                    <div class="mt-3">
                                        <label class="font-semibold" for="">Drop Time</label>
                                        <input type="time" wire:model.live='endTime' maxlength="4"
                                            placeholder="time" required
                                            class=" bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
                                    </div>


                                    @if ($hours)
                                        <div class="flex items-center justify-between">
                                            <p class="text-center w-full text-xl text-green-600 font-extrabold mt-4">
                                                Total Hours: {{ $hours }} </p>
                                            <p class="text-center w-full text-xl text-green-600 font-extrabold mt-4">
                                                Total Price: {{ $ride->price * $hours }} </p>
                                        </div>
                                    @endif


                                    <button type="submit"
                                        class="main-color mt-4 text-xl w-full text-white p-2 rounded-sm">
                                        Book Now
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    @endif

    <section class="overflow-hidden bg-white  font-poppins dark:bg-gray-800">
        <div class="max-w-6xl  mx-auto lg:py-4 md:px-4">
            <div class="flex flex-wrap -mx-4">
                <div class="w-full md:w-1/3 md:mb-0 z-0" x-data="{ mainImage: '{{ url('storage') }}/{{$ride->images[0]}}' }">
                    <div class="sticky top-0 z-50 overflow-hidden ">
                        <div class="relative  lg:h-2/ ">
                            <img x-bind:src="mainImage" alt="" class="object-cover w-full lg:h-full ">
                        </div>
                        <div class="flex-wrap hidden md:flex ">
                            @foreach ($ride->images as $image)
                                <div class="w-1/2 p-2 sm:w-1/4"
                                    x-on:click="mainImage='{{ url('storage') }}/{{$image}}'">
                                    <img src="{{ url('storage') }}/{{$image}}" alt="{{ $ride->name }}"
                                        class="object-cover w-full  cursor-pointer hover:border hover:border-blue-500">
                                </div>
                            @endforeach



                        </div>

                    </div>
                </div>
                <div class="w-full px-4 md:w-1/2 ">
                    <div class="lg:pl-20">
                        <div class="mb-2 [&>ul]:list-disc [&>ul]:ml-4">
                            <h2 class="max-w-xl mb-1 text-2xl font-bold dark:text-gray-400 md:text-4xl">
                                {{ $ride->name }}</h2>
                            <p class="inline-block mb-1 text-4xl font-bold text-gray-700 dark:text-gray-400 ">
                                <span>{{ Number::currency($ride->price, 'INR') }}</span>
                                <span
                                    class="text-base font-normal text-gray-500 line-through dark:text-gray-400">{{ Number::currency($ride->max_price, 'INR') }}</span>
                            </p>

                        </div>



                        @if ($ride->ride_type === 'one_way')
                            <div class="flex flex-wrap items-center gap-4">
                                <button wire:click='tabValue(["one_way","{{$ride->price}}","{{$ride->name}}","{{$ride->category->name}}"])'
                                    class="w-full p-4 bg-sky-500 rounded-md lg:w-2/5 dark:text-gray-200 text-gray-50 hover:bg-blue-600 dark:bg-blue-500 dark:hover:bg-blue-700">
                                    <span wire:loading.remove wire:target='tabValue(["one_way","{{$ride->price}}","{{$ride->name}}","{{$ride->category->name}}"])'>
                                        Book Now
                                    </span>

                                    <span wire:loading wire:target='tabValue(["one_way","{{$ride->price}}","{{$ride->name}}","{{$ride->category->name}}"])'>
                                        Adding...
                                    </span>

                                </button>
                            </div>
                        @endif

                        @if ($ride->ride_type === 'local')
                            <div class="flex flex-wrap items-center gap-4">
                                <button wire:click='tabValue("local")'
                                    class="w-full p-4 bg-sky-500 rounded-md lg:w-2/5 dark:text-gray-200 text-gray-50 hover:bg-blue-600 dark:bg-blue-500 dark:hover:bg-blue-700">
                                    <span wire:loading.remove wire:target='tabValue("local")'>
                                        Book Now
                                    </span>

                                    <span wire:loading wire:target='tabValue("local")'>
                                        Adding...
                                    </span>

                                </button>
                            </div>
                        @endif

                        @if ($ride->ride_type === 'self_drive')
                            <div class="flex flex-wrap items-center gap-4">
                                <button wire:click='tabValue("self_drive")'
                                    class="w-full p-4 bg-sky-500 rounded-md lg:w-2/5 dark:text-gray-200 text-gray-50 hover:bg-blue-600 dark:bg-blue-500 dark:hover:bg-blue-700">
                                    <span wire:loading.remove wire:target='tabValue("self_drive")'>
                                        Book Now
                                    </span>

                                    <span wire:loading wire:target='tabValue("self_drive")'>
                                        Adding...
                                    </span>

                                </button>
                            </div>
                        @endif


                    </div>
                </div>
            </div>

    </section>

    <section class=" font-poppins dark:bg-gray-800 rounded-lg">

        <div class="px-4 py-4 mx-auto max-w-7xl lg:py-6 md:px-6">

            <div class="lg:flex mb-5 -mx-3">

                <div class="w-full pr-2 flex lg:p-5 p-2 main-color rounded-s">

                    <div class="mr-2 flex items-center">
                        <svg class="lg:w-5 w-5" fill="#fff" xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M135.2 117.4L109.1 192l293.8 0-26.1-74.6C372.3 104.6 360.2 96 346.6 96L165.4 96c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32l181.2 0c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2l0 144 0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L96 400l0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L0 256c0-26.7 16.4-49.6 39.6-59.2zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm288 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z" />
                        </svg>

                    </div>

                    <div class="">
                        <h2 class="lg:text-3xl text-xl font-medium text-white dark:text-gray-400">Trip Packages For
                        </h2>

                        @if ($ride->ride_type === 'one_way')
                            <div class="flex mt-2 text-white items-center">
                                <p>{{ $ride->brand->name }} </p>
                                <svg width="35" height="25" fill="#fff" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                    <path
                                        d="M438.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L338.8 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l306.7 0L233.4 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z" />
                                </svg>
                                <p>{{ $cityTo->name }}</p>
                            </div>
                        @else
                            <div class="flex mt-2">
                                <p>{{ $ride->brand->name }} </p>
                            </div>
                        @endif



                    </div>




                </div>
                <div class="w-full pr-2 flex lg:p-5 p-2 md:mt-0 mt-2 rounded-r border-2 border-[#1e9cfd]">
                    <div class="mr-2 flex items-center">
                        <svg class="lg:w-5 w-5" fill="#1e9cfd" xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zM337 209L209 337c-9.4 9.4-24.6 9.4-33.9 0l-64-64c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l47 47L303 175c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9z" />
                        </svg>

                    </div>


                    <div class="">
                        <h2 class="lg:text-3xl text-xl font-medium main-color-text dark:text-gray-400">Trip Type</h2>
                        <div class="flex mt-2">
                            <p class="uppercase main-color-text">
                                {{ $ride->ride_type === 'one_way' ? 'Oneway' : $ride->ride_type }}
                            </p>


                        </div>
                    </div>




                </div>

            </div>


            <div class="flex flex-wrap mb-5 -mx-3">
                <div class="w-full pr-2 lg:w-1/4 lg:block">

                    {{-- <div class="p-4 mb-5 bg-white border border-gray-200 dark:border-gray-900 dark:bg-gray-900">
                        <h2 class="text-2xl font-medium text-sky-500 dark:text-gray-400">Trip Details</h2>

                        @if ($ride->ride_type === 'one_way')
                            <div class="">
                                <div class="flex mt-3">
                                    <svg width="30" height="20" xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                        <path
                                            d="M135.2 117.4L109.1 192l293.8 0-26.1-74.6C372.3 104.6 360.2 96 346.6 96L165.4 96c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32l181.2 0c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2l0 144 0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L96 400l0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L0 256c0-26.7 16.4-49.6 39.6-59.2zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm288 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z" />
                                    </svg>
                                    &nbsp; <p>PickUp City : </p> &nbsp; &nbsp; <span>{{ $ride->brand->name }}</span>

                                </div>
                                <div class="flex mt-3">
                                    <svg width="30" height="20" xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                        <path
                                            d="M135.2 117.4L109.1 192l293.8 0-26.1-74.6C372.3 104.6 360.2 96 346.6 96L165.4 96c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32l181.2 0c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2l0 144 0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L96 400l0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L0 256c0-26.7 16.4-49.6 39.6-59.2zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm288 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z" />
                                    </svg>
                                    &nbsp; <p>Drop City : </p> &nbsp; &nbsp; <span>{{ $cityTo->name }}</span>

                                </div>
                            </div>
                        @else
                            <div class="flex mt-3">
                                <svg width="30" height="20" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                    <path
                                        d="M135.2 117.4L109.1 192l293.8 0-26.1-74.6C372.3 104.6 360.2 96 346.6 96L165.4 96c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32l181.2 0c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2l0 144 0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L96 400l0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L0 256c0-26.7 16.4-49.6 39.6-59.2zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm288 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z" />
                                </svg>
                                &nbsp; <p>PickUp City : </p> &nbsp; &nbsp; <span>{{ $ride->brand->name }}</span>

                            </div>
                        @endif



                    </div> --}}


                    <div class="p-4 mb-5 bg-white border border-gray-200 dark:border-gray-900 dark:bg-gray-900">
                        <h2 class="text-2xl font-medium text-sky-500 dark:text-gray-400"> Need Help Booking?</h2>
                        <div class="flex mt-3">
                            <p>Call Our Customer Care Executive. We Are Available 24×7 Just Dial.</p>

                        </div>
                        <div class="flex mt-3">
                            <div class="bg-sky-600 p-1 text-sky-300 rounded-lg">
                                <svg width="30" fill="white" height="20" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                    <path
                                        d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z" />
                                </svg>
                            </div>
                            &nbsp; <a href="tel:+91-7088873331"
                                class="text-sky-700 font-bold text-xl">+91-7088873331</a>

                        </div>
                        <div class="flex mt-3">
                            <div class="bg-green-500 p-1 text-sky-300 rounded-full">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" fill="white" height="20"
                                    viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                    <path
                                        d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7 .9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z" />
                                </svg>
                            </div>
                            &nbsp; &nbsp; <a href="tel:+91-7088873331"
                                class="text-green-500 font-bold text-xl">+91-7088873331</a>

                        </div>
                    </div>
                </div>
                <div class="w-full lg:w-3/4">
                    <div class="px-3 mb-4">
                        <div
                            class="items-center justify-between hidden px-3 py-2 bg-gray-100 md:flex dark:bg-gray-900 ">
                            <div class="text-2xl"> Related Tour Package ({{ count($rides) }})</div>
                            {{-- <div class="flex items-center justify-between">
                                <select wire:model.live='sort' id=""
                                    class="block w-40 text-base bg-gray-100 cursor-pointer dark:text-gray-400 dark:bg-gray-900">
                                    <option value="latest">Sort by latest</option>
                                    <option value="price">Sort by Price</option>
                                </select>


                            </div> --}}

                        </div>
                    </div>
                    <div class="lg:flex grid flex-wrap items-center">

                        @foreach ($prices as $price)
                            <div
                                class="w-full mb-2 bg-white p-1 border border-gray-300 dark:border-gray-700 shadow-2xl shadow-sky-100">
                                <div class="lg:flex  justify-between  ">
                                    <div class="relative">
                                        <a href="/route/{{ $ride->slug }}" class="">
                                            <img src="{{ url('storage')}}/{{$price->category->image}}"
                                                alt="{{ $ride->name }}"
                                                class="object-contain lg:w-80 w-full h-26 mx-auto">
                                        </a>
                                    </div>
                                    <div class="p-1 text-center">
                                        <div class=" justify-between gap-2 mb-2">
                                            <h3 class="text-xm font-extrabold uppercase dark:text-gray-400">
                                                {{ $ride->name }}
                                            </h3>

                                        </div>
                                        <div
                                            class="lg:flex grid grid-rows-1 gap-0 place-items-center text-center items-end">
                                            <div class="px-2 grid grid-rows-1 gap-0 place-items-center lg:mt-5 mt-0 ">
                                                <h4 class="text-sm font-medium dark:text-gray-400">
                                                    {{ $price->category->name }}
                                                </h4>
                                                <img src="{{ url('storage') }}/{{$price->category->image}}"
                                                    alt="{{ $price->category->name }}"
                                                    class="object-contain w-10 h-10 mx-auto ">

                                                <div class="flex">
                                                    <svg width="20" height="20" fill="gold"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                                        <path
                                                            d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z" />
                                                    </svg>
                                                    <svg width="20" height="20" fill="gold"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                                        <path
                                                            d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z" />
                                                    </svg>
                                                    <svg width="20" height="20" fill="gold"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                                        <path
                                                            d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z" />
                                                    </svg>
                                                    <svg width="20" height="20" fill="gold"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                                        <path
                                                            d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z" />
                                                    </svg>
                                                    <svg width="20" height="20" fill="gold"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                                        <path
                                                            d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z" />
                                                    </svg>
                                                </div>
                                                {{-- <p class="text-xs text-left w-10/12">{{ $ride->category->name }}
                                                    {{ $ride->name }}
                                                </p> --}}
                                            </div>
                                            <div class="">

                                                <div class="flex mt-2">
                                                    <div class="p-1">
                                                        <img src="{{ url('/cab_images/plastic-bottle.png') }}"
                                                            alt="{{ $ride->name }}"
                                                            class="object-contain w-10 h-10 mx-auto ">
                                                        <p class="text-xs">Water Bottle</p>
                                                    </div>
                                                    <div class="p-1">
                                                        <img src="{{ url('/cab_images/cursor.png') }}"
                                                            alt="{{ $ride->name }}"
                                                            class="object-contain w-10 h-10 mx-auto ">
                                                        <p class="text-xs">Quick Booking</p>
                                                    </div>
                                                    <div class="p-1">
                                                        <img src="{{ url('/cab_images/driver.png') }}"
                                                            alt="{{ $ride->name }}"
                                                            class="object-contain w-10 h-10 mx-auto ">
                                                        <p class="text-xs">Qualified Driver </p>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                    <div class="p-3 text-center">

                                        <div class="text-lg text-center">
                                            <p
                                                class="text-base font-normal text-gray-500 line-through dark:text-gray-400">
                                                {{ Number::currency($price->max_price, 'INR') }}</p>
                                            <p class="text-black-600 text-2xl font-bold dark:text-black-600">
                                                {{ Number::currency($price->price, 'INR') }}</p>
                                        </div>
                                        {{-- <div class="flex justify-center p-1 ">
                                            <a href="/route/{{ $ride->slug }}"
                                                class="text-white text-xm w-full  bg-sky-500 hover:bg-sky-900 p-2 shadow-2xl shadow-black rounded-full flex items-center justify-center dark:text-gray-400 hover:text-b-500 dark:hover:text-red-300">
                                                View
                                            </a>
                                        </div> --}}
                                        @if ($ride->ride_type === 'one_way')
                                            <div class="flex flex-wrap items-center gap-4">
                                                <button wire:click='tabValue(["one_way","{{$price->price}}","{{$ride->name}}","{{$price->category->name}}"])'
                                                    class="w-full p-4 bg-sky-500 rounded-full  dark:text-gray-200 text-gray-50 hover:bg-blue-600 dark:bg-blue-500 dark:hover:bg-blue-700">
                                                    <span wire:loading.remove wire:target='tabValue("one_way")'>
                                                        Book Now
                                                    </span>

                                                    <span wire:loading wire:target='tabValue("one_way")'>
                                                        Adding...
                                                    </span>

                                                </button>
                                            </div>
                                        @endif

                                    </div>

                                </div>
                            </div>
                        @endforeach

                    </div>
                    <!-- pagination start -->
                    <div class="flex justify-end mt-6">
                        {{ $rides->links() }}
                    </div>
                    <!-- pagination end -->
                </div>
            </div>
        </div>
    </section>
    <section class=" font-poppins dark:bg-gray-800 rounded-lg">
        <h2 class="text-center text-sky-500 text-3xl font-bold mb-5"> Book Cab in Easy 4 Step</h2>
        <div class="lg:flex grid bg-sky-500 p-2 rounded-xl gap-2">
            <div class="w-full">
                <div class="flex items-center justify-start">
                    <div class="bg-white rounded-full p-5">
                        <svg width="25" height="25" fill="#0ea5e9" xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M135.2 117.4L109.1 192l293.8 0-26.1-74.6C372.3 104.6 360.2 96 346.6 96L165.4 96c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32l181.2 0c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2l0 144 0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L96 400l0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L0 256c0-26.7 16.4-49.6 39.6-59.2zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm288 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z" />
                        </svg>
                    </div>
                    <h5 class="text-white px-2 font-bold text-xm">Pick You Destination</h5>
                </div>
            </div>
            <div class="w-full">
                <div class="flex items-center justify-start mt-1">
                    <div class="bg-white rounded-full p-5">
                        <svg width="25" height="25" fill="#0ea5e9" xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M135.2 117.4L109.1 192l293.8 0-26.1-74.6C372.3 104.6 360.2 96 346.6 96L165.4 96c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32l181.2 0c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2l0 144 0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L96 400l0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L0 256c0-26.7 16.4-49.6 39.6-59.2zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm288 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z" />
                        </svg>
                    </div>
                    <h5 class="text-white px-2 font-bold text-xm">Choose You Cab</h5>
                </div>
            </div>
            <div class="w-full">
                <div class="flex items-center justify-start">
                    <div class="bg-white rounded-full p-5 mt-1">
                        <svg width="25" height="25" fill="#0ea5e9" xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M135.2 117.4L109.1 192l293.8 0-26.1-74.6C372.3 104.6 360.2 96 346.6 96L165.4 96c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32l181.2 0c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2l0 144 0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L96 400l0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L0 256c0-26.7 16.4-49.6 39.6-59.2zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm288 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z" />
                        </svg>
                    </div>
                    <h5 class="text-white px-2 font-bold text-xm">Fill Details</h5>
                </div>
            </div>
            <div class="w-full">
                <div class="flex items-center justify-start">
                    <div class="bg-white rounded-full p-5 mt-1">
                        <svg width="25" height="25" fill="#0ea5e9" xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                            <path
                                d="M135.2 117.4L109.1 192l293.8 0-26.1-74.6C372.3 104.6 360.2 96 346.6 96L165.4 96c-13.6 0-25.7 8.6-30.2 21.4zM39.6 196.8L74.8 96.3C88.3 57.8 124.6 32 165.4 32l181.2 0c40.8 0 77.1 25.8 90.6 64.3l35.2 100.5c23.2 9.6 39.6 32.5 39.6 59.2l0 144 0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L96 400l0 48c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-48L0 256c0-26.7 16.4-49.6 39.6-59.2zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm288 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z" />
                        </svg>
                    </div>
                    <h5 class="text-white px-2 font-bold text-xm">Make Payment and Booked</h5>
                </div>
            </div>


        </div>

        <div class="bg-white p-0 mt-0 ">
            <h2 class="text-3xl mt-5 font-bold">{{ $ride->name }}</h2>
            <div class="description mt-2">
                {!! Str::markdown($ride->description) !!}

            </div>
        </div>

        <div class="p-2 bg-white mt-3">
            <h2 class="text-sky-500 font-medium p-2 text-xl bg-slate-200">{{ $ride->name }} Cab Oneway Price / Per
                k.m. Price</h2>



            <div class="relative overflow-x-auto shadow-md sm:rounded-lg mt-2">
                <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead
                        class="text-xs text-gray-700 uppercase bg-sky-500 text-white dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3 bg-sky-500 dark:bg-sky-800">
                                Vehicle Type
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Model Type
                            </th>
                            <th scope="col" class="px-6 py-3 bg-sky-500 dark:bg-sky-800">
                                Passanger Capacity
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Luggage Capacity
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Rate/km
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Fare
                            </th>

                        </tr>
                    </thead>
                    <tbody>

                        @foreach ($rides as $item)
                            <tr class="border-b border-gray-200 dark:border-gray-700">
                                <th scope="row"
                                    class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap bg-gray-50 dark:text-white dark:bg-gray-800">
                                    {{ $item->category->name }}
                                </th>
                                <td class="px-6 py-4">
                                    {{ $item->category->model }}
                                </td>
                                <td class="px-6 py-4 bg-gray-50 dark:bg-gray-800">
                                    {{ $item->category->passanger_capacity }}
                                </td>
                                <td class="px-6 py-4">
                                    {{ $item->category->luggage_capacity }}
                                </td>
                                <td class="px-6 py-4">
                                    {{ Number::currency($item->extra_km_charge, 'INR') }}
                                </td>
                                <td class="px-6 py-4">
                                    {{ Number::currency($item->price, 'INR') }}
                                </td>
                            </tr>
                        @endforeach


                    </tbody>
                </table>
            </div>


        </div>
        <div class="p-2 bg-white mt-3">
            <section class=" py-2 ">
                <div class="container flex flex-col justify-center p-4 mx-auto md:p-8">
                    <h2 class="text-center text-sky-500 text-3xl font-bold mb-5"> Frequently Asked Questions</h2>

                    <div class="flex flex-col divide-y sm:px-0 lg:px-2 xl:px-4 divide-gray-700">
                        <details>
                            <summary class="py-2 outline-none cursor-pointer focus:underline">1. What are the options
                                available for {{ $ride->name }}?</summary>
                            <div class="px-4 pb-4">
                                <p>We have 2 options to travel from {{ $ride->name }} Way Cab and Proud Trip.
                                </p>
                            </div>
                        </details>
                        <details>
                            <summary class="py-2 outline-none cursor-pointer focus:underline">2. What is the minimum
                                cab fare from {{ $ride->name }}?</summary>
                            <div class="px-4 pb-4">
                                <p>On Duracabs you get a cab from {{ $ride->brand->name }} to {{ $cityTo->name }} in
                                    only {{ $ride->price }}.
                                </p>
                            </div>
                        </details>
                        <details>
                            <summary class="py-2 outline-none cursor-pointer focus:underline">3. How much time will it
                                take to reach {{ $ride->brand->name }} from {{ $cityTo->name }} by car?</summary>
                            <div class="px-4 pb-4">
                                <p>It takes you about 4.5 hours to go from Agra to Delhi by car. </p>
                            </div>
                        </details>
                        <details>
                            <summary class="py-2 outline-none cursor-pointer focus:underline">4. What are the
                                advantages of online cab booking from Duracab?</summary>
                            <div class="px-4 pb-4">
                                <p>There are many advantages of booking cabs online with Duracab. You can book cabs on
                                    call or website from the comfort of your home and save a lot of time and effort.
                                </p>
                            </div>
                        </details>
                        <details>
                            <summary class="py-2 outline-none cursor-pointer focus:underline">5. Which is the most
                                economical cab available in {{ $ride->brand->name }}?</summary>
                            <div class="px-4 pb-4">
                                <p>The cheapest cab we have is the Hatchback Wagon R which can seat 4 people comfortably
                                    and is available at a fare of only Rs.9 per km.
                                </p>
                            </div>
                        </details>

                    </div>
                </div>
            </section>

        </div>
        <div class="p-2 bg-white mt-3">
            <h2 class="text-sky-500 font-medium p-2 text-xl bg-slate-200"> Why choose Duracabs for cabs in
                {{ $ride->brand->name }}?</h2>



            <div class="relative overflow-x-auto shadow-md sm:rounded-lg mt-2">
                <h3 class=" font-normal p-2 text-xm">Here are the reasons why you should choose Duracabs in Agra. </h3>

                <div class="lg:px-10 px-2 py-5">
                    <p class="font-bold text-xm">1. You just need to sit back and relax. Once you book Duracabs you
                        just need to relax on your journey. </p>
                    <p class="font-bold text-xm">2. Duracabs provides door-to-door pickup and drop. You will be picked
                        up and dropped at your preferred location with no extra charges. </p>
                    <p class="font-bold text-xm">3. The chauffeurs that Duracabs provides are experts and experienced.
                        Your drivers will guide you to the best spots possible. </p>
                    <p class="font-bold text-xm">4. Duracabs provides flexible payment options. You can choose the mode
                        of payment you want once the trip is complete. </p>
                    <p class="font-bold text-xm">5. Duracabs charged no Cancellation Fees. We understand that plans can
                        get changed at the very last minute. </p>
                </div>
            </div>
        </div>
        <div class="p-2 bg-white mt-3">
            <h2 class="text-sky-500 font-medium p-2 text-xl bg-slate-200">One Way Cab/Taxi Route From
                {{ $ride->brand->name }} </h2>
            <div class="overflow-x-auto shadow-md sm:rounded-lg mt-2 flex justify-center">
                <div class="p-5 flex  justify-between  w-2/3">
                    <div class="">
                        @foreach ($links as $link)
                            <li><a wire:navigate href="{{ $link->url }}"
                                    class="underline flex-none w-50 text-center ">
                                    <span>{{ $link->title }} </span></a></li>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
