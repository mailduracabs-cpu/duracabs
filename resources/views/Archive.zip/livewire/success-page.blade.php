<div class="w-full max-w-[85rem] py-10 px-4 sm:px-6 lg:px-8 mx-auto">
    <section class=" dark:bg-gray-800 ">
        <div
            class="justify-center flex-1 max-w-6xl  mx-auto bg-white border rounded-md dark:border-gray-900 dark:bg-gray-900 ">
            <hr class="h-7 mb-5 bg-sky-500 border-0 dark:bg-gray-700" />
            <div class="md:py-0 md:px-10">

                <div class="flex justify-between">
                    <div class="w-1/2 ">
                        <img class="w-1/2" src="{{ url('storage', 'images/Duracab-Logo-425x115.png') }}" />
                    </div>
                    <div class="">


                        <div class=""> <span>Booking No :</span> <a href="tel:+917088873331"
                                class="font-bold">+91-7088873331 </a></div>
                        <div class=""> <span>Whatsapp No :</span> <a href="tel:+917088873332"
                                class="font-bold">+91-7088873332 </a></div>
                        <p> 24 x 7 Customer Support </p>
                    </div>
                </div>
                {{-- <button wire:click="createInvoice"> Create Invoice

            </button> --}}

                <h1 class="px-4 mb-8 text-2xl my-5 font-semibold tracking-wide text-gray-700 dark:text-gray-300 ">
                    Thank you. Your order has been received. </h1>
                <hr class="h-1 mb-5 bg-sky-500 border-0 dark:bg-gray-700" />
                <div
                    class="flex flex-col border-b border-gray-200 dark:border-gray-700  items-stretch  w-full h-full px-4 mb-8 md:flex-row xl:flex-auto md:space-x-6 lg:space-x-6 xl:space-x-0">


                    <div class="w-1/2">
                        <p class="text-xl text-left pb-4  font-semibold leading-6  text-gray-800 dark:text-gray-400">
                            Traveller Detail : <br />

                        </p>
                        <div class="flex items-center justify-center w-full pb-6 space-x-4 md:justify-start">
                            <div class="flex flex-col items-start justify-start space-y-2">
                                <div class="flex">
                                    <p
                                        class="text-lg font-semibold leading-4 text-left text-gray-800 dark:text-gray-400">
                                        Name : {{ $order->address->full_name }}</p>
                                </div>
                                <p class="text-sm leading-4 cursor-pointer dark:text-gray-400">
                                    <span class="text-lg font-semibold leading-4 text-gray-800 dark:text-gray-400">
                                        Mobile : </span> {{ $order->address->phone }}
                                </p>
                                <p class="text-sm leading-4 cursor-pointer dark:text-gray-400">
                                    <span class="text-lg font-semibold leading-4 text-gray-800 dark:text-gray-400">
                                        Email : </span> {{ $order->address->email }}
                                </p>
                                {{-- <p class="w-1/2 text-sm leading-4 text-gray-600 dark:text-gray-400">
                                  <span class="text-lg font-semibold leading-4 text-gray-800 dark:text-gray-400"> Address :  </span>   {{ $order->address->street_address }}</p> --}}

                                {{-- <p class="text-sm leading-4 text-gray-600 dark:text-gray-400">
                                    {{ $order->address->city }}, {{ $order->address->state }},
                                    {{ $order->address->zip_code }}</p> --}}

                            </div>
                        </div>
                    </div>
                    <div class="w-1/2 px-8">
                        <div class="">
                            <div class="flex justify-end  ">
                                <div class="">
                                    <h1 class="text-3xl text-right text-sky-600 font-bold uppercase">Booking ID : <span
                                            class="text-3xl text-sky-600 font-bold">{{ $order->id }}</span></h1>
                                    <p class="text-xl text-right    leading-6  text-gray-800 dark:text-gray-400">

                                        <span class="font-semibold"> Generated On : </span>
                                        <span class="text-lg">Date
                                            {{ $order->created_at->setTimezone('Asia/Kolkata')->format('d-m-y') }} Time
                                            {{ $order->created_at->setTimezone('Asia/Kolkata')->format('h:i a') }}</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex flex-wrap items-center pb-4 mb-10 border-b border-gray-200 dark:border-gray-700">
                    <div class="w-full px-4 mb-4 md:w-1/4">
                        <p class="mb-2 text-sm leading-5 text-gray-600 dark:text-gray-400 ">
                            Order Number: </p>
                        <p class="text-base font-semibold leading-4 text-gray-800 dark:text-gray-400">
                            {{ $order->id }}</p>
                    </div>
                    <div class="w-full px-4 mb-4 md:w-1/4">
                        <p class="mb-2 text-sm leading-5 text-gray-600 dark:text-gray-400 ">
                            Start Date & Time: </p>
                        <p class="text-base font-semibold leading-4 text-gray-800 dark:text-gray-400">
                            {{ \Carbon\Carbon::parse($order->date)->format('d/m/Y') }}
                            {{ \Carbon\Carbon::parse($order->time)->format('h:i:a') }}</p>
                    </div>




                    <div class="w-full px-4 mb-4 md:w-1/4">
                        <p class="mb-2 text-sm font-medium leading-5 text-gray-800 dark:text-gray-400 ">
                            Total: </p>
                        <p class="text-base font-semibold leading-4 text-blue-600 dark:text-gray-400">
                            {{ Number::currency($order->grand_total, 'INR') }} </p>
                    </div>
                    <div class="w-full px-4 mb-4 md:w-1/4">
                        <p class="mb-2 text-sm leading-5 text-gray-600 dark:text-gray-400 ">
                            Payment Method: </p>
                        <p class="text-base font-semibold leading-4 text-gray-800 dark:text-gray-400 ">
                            {{ $order->payment_method == 'cash' ? 'Cash' : 'Online' }} </p>
                    </div>
                </div>
                <div class="px-2 mb-10">
                    <div
                        class="flex flex-col items-stretch justify-center w-full space-y-4 md:flex-row md:space-y-0 md:space-x-8">
                        <div class="flex flex-col w-1/2 px-2 space-y-2 capitalize ">
                            <h2 class="mb-2 text-xl font-semibold text-gray-700 dark:text-gray-400">Trip Details</h2>

                            @if ($order->ride_type === 'return')
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">
                                        <div class="flex flex-col items-center justify-start">
                                            <p class="text-lg font-semibold  text-gray-800 dark:text-gray-400">
                                                Trip Route<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="w-1/2 text-right text-lg text-gray-800 dark:text-gray-400 ">
                                        {{ $order->cityFrom }} -> {{ $order->cityTo }}</p>
                                </div>
                            @endif

                            @if ($product->ride_type === 'one_way')
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">
                                        <div class="flex flex-col items-center justify-start">
                                            <p class="text-lg font-semibold  text-gray-800 dark:text-gray-400">
                                                Trip Route<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg   text-gray-800 dark:text-gray-400 ">
                                        {{ $product->name }}</p>
                                </div>
                            @endif

                            <div class="flex items-start justify-between w-full">
                                <div class="flex items-center justify-center ">

                                    <div class="flex flex-col items-center justify-start">
                                        <p class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                            Trip Type<br><span class="text-sm font-normal"> </span>
                                        </p>
                                    </div>
                                </div>
                                <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                    {{ $order->ride_type }}</p>
                            </div>
                            <div class="flex items-start justify-between w-full">
                                <div class="flex items-center justify-center ">

                                    <div class="flex flex-col items-center justify-start">
                                        <p class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                            Taxi Type<br><span class="text-sm font-normal"> </span>
                                        </p>
                                    </div>
                                </div>
                                <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                    {{ $order->productName }}</p>
                            </div>
                            <div class="flex items-start justify-between w-full">
                                <div class="flex items-center justify-center ">

                                    <div class="flex flex-col items-center justify-start">
                                        <p class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                            Pickup Address<br><span class="text-sm font-normal"> </span>
                                        </p>
                                    </div>
                                </div>
                                <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                    {{ $order->address->pickup_address }}</p>
                            </div>
                            @if ($order->address->drop_address)
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                Drop Address<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ $order->address->drop_address }}</p>
                                </div>
                            @endif

                            @if ($order->ride_type === 'one_way')
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                Total KM<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ $product->km_limit }}</p>
                                </div>
                            @endif

                            @if ($order->ride_type === 'return')
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                Total KM<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ $order->total_km }}</p>
                                </div>
                            @endif

                            @if ($order->ride_type === 'return' || 'self_drive')
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                End Date<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ \Carbon\Carbon::parse($order->dateTo)->format('d/m/Y') }}</p>
                                </div>
                            @endif
                            @if ($order->ride_type === 'self_drive')
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                End Time<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ \Carbon\Carbon::parse($order->time)->format('h:i a') }}</p>
                                </div>
                            @endif


                            @if ($order->ride_type === 'one_way')
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                Total Hour<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ $product->hr_limit }}</p>
                                </div>
                            @endif

                            @if ($order->ride_type === 'return')
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                Total Days<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ $days + 1 }}</p>
                                </div>
                            @endif

                            @if ($order->address->comments)
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                Comments<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ $order->address->comments }}</p>
                                </div>
                            @endif
                            @if ($order->address->number_travellers)
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                Number Of Travellers<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ $order->address->number_travellers }}</p>
                                </div>
                            @endif
                            @if ($order->address->number_luggage)
                                <div class="flex items-start justify-between w-full">
                                    <div class="flex items-center justify-center ">

                                        <div class="flex flex-col items-center justify-start">
                                            <p
                                                class="text-lg font-semibold  leading-6 text-gray-800 dark:text-gray-400">
                                                Number of Luggage<br><span class="text-sm font-normal"> </span>
                                            </p>
                                        </div>
                                    </div>
                                    <p class="text-lg  leading-6 text-gray-800 dark:text-gray-400 ">
                                        {{ $order->address->number_luggage }}</p>
                                </div>
                            @endif


                        </div>
                        <div class="flex flex-col w-1/2 space-y-6 ">
                            <h2 class="mb-2 text-xl font-semibold text-gray-700 dark:text-gray-400">Order details</h2>
                            <div
                                class="flex flex-col items-center justify-center w-full pb-4 space-y-4 border-b border-gray-200 dark:border-gray-700">
                                <div class="flex justify-between w-full">
                                    <p class="text-base leading-4 text-gray-800 dark:text-gray-400">Subtotal</p>
                                    <p class="text-base font-semibold leading-4 text-gray-600 dark:text-gray-400">
                                        {{ Number::currency($order->grand_total - $order->tax + $order->coupon_value, 'INR') }}
                                    </p>
                                </div>
                                <div class="flex items-center justify-between w-full">
                                    <p class="text-base leading-4 text-gray-800 dark:text-gray-400">Discount
                                    </p>
                                    <p class="text-base leading-4 text-gray-600 dark:text-gray-400">
                                        {{ Number::currency($order->coupon_value, 'INR') }}</p>
                                </div>
                                @if ($order->ride_type === 'return')
                                    <div class="flex items-center justify-between w-full">
                                        <p class="text-base leading-4 text-gray-800 dark:text-gray-400">Driver
                                            Allowance
                                        </p>
                                        <p class="text-base leading-4 text-gray-600 dark:text-gray-400">
                                            {{ Number::currency($driverCharge * $days, 'INR') }}</p>
                                    </div>
                                @endif

                                <div class="flex items-center justify-between w-full">
                                    <p class="text-base leading-4 text-gray-800 dark:text-gray-400">Tax</p>
                                    <p class="text-base leading-4 text-gray-600 dark:text-gray-400">
                                        {{ Number::currency($order->tax, 'INR') }}</p>
                                </div>
                            </div>
                            <div class="flex items-center justify-between w-full">
                                <p class="text-base font-semibold leading-4 text-gray-800 dark:text-gray-400">Total</p>
                                <p class="text-base font-semibold leading-4 text-gray-600 dark:text-gray-400">
                                    {{ Number::currency($order->grand_total, 'INR') }}</p>
                            </div>
                            <h2 class="mb-2 text-xl font-semibold text-gray-700 dark:text-gray-400">Payment details
                            </h2>
                            <div
                                class="flex flex-col items-center justify-center w-full pb-4 space-y-4 border-b border-gray-200 dark:border-gray-700">

                                @if ($invoices)
                                    @foreach ($invoices as $key => $item)
                                        <div class="flex justify-between w-full">
                                            <p class="text-base leading-4 text-gray-800 dark:text-gray-400 uppercase">
                                                Invoice (#{{ $item->id }})</p>
                                            <p
                                                class="text-base font-semibold leading-4 uppercase text-gray-600 dark:text-gray-400">
                                                {{ $item->status }}
                                            </p>

                                            <p
                                                class="text-base font-semibold leading-4 text-gray-600 dark:text-gray-400">
                                                {{ $item->date }}
                                            </p>

                                            <p
                                                class="text-base font-semibold leading-4 text-gray-600 dark:text-gray-400">
                                                {{ $item->ammount }}
                                            </p>

                                        </div>
                                    @endforeach

                                @endif





                            </div>
                            <div class="flex items-center justify-between w-full">
                                <p class="text-base font-semibold leading-4 text-gray-800 dark:text-gray-400">Total
                                    Paid</p>
                                <p class="text-base font-semibold leading-4 text-gray-600 dark:text-gray-400">
                                    {{ Number::currency($InvoiceSum, 'INR') }}</p>
                            </div>
                            <div class="flex items-center justify-between w-full">
                                <p class="text-base font-semibold leading-4 text-gray-800 dark:text-gray-400">Total Due
                                </p>
                                <p class="text-base font-semibold leading-4 text-gray-600 dark:text-gray-400">
                                    {{ Number::currency($order->grand_total - $InvoiceSum, 'INR') }}</p>


                            </div>
                        </div>

                    </div>
                </div>

                <div class="">
                    <h1 class="font-semibold text-lg">Booking Terms and Conditions</h1>

                    <p class="text-sm">The Services are provided by Dura Cabs Services (hereinafter referred to as
                        "Dura" or "Duracabs"), located at Uttar Pradesh Agra 282001. Please read these terms carefully.
                        By using our services, you are agreeing to all terms & conditions set forth. In this agreement,
                        the words "including" and "include" mean "including, but not limited to."</p>
                    <ul class="space-y-2 my-4">
                        <li>> Collect Rs.{{ $order->grand_total }}/- collect the below extra(add 5%GST on all
                            extras)</li>
                        @if ($order->ride_type === 'one_way')
                            <li>> Extra Hours(Beyond hours)will be Charged :Rs.{{ $product->extra_hr_charge }}/-hr.
                            </li>
                            <li>> Extra KM (Beyond hours)will be Charged :Rs{{ $product->extra_km_charge }}/- km</li>
                        @endif

                        @if ($order->ride_type === 'return')
                            <li>> Extra KM (Beyond hours)will be Charged :Rs{{ $perKm }}/- km</li>
                        @endif


                        @if ($order->ride_type === 'self_drive')
                            <li>> This fare dose not include inter-state tax , toll , parking & fule please pay directly
                                to the
                                authorities.</li>

                            <li>
                                > Pickup and drop charges are additional and will depend on the distance from the
                                pickup/drop location to the designated rental office.
                                The charge will also vary depending on the time of day. Premium rates may apply for
                                late-night or early-morning services (between [Specify Time Range, e.g., 10 PM to 6
                                AM]).
                            </li>

                            <li>
                                > The charge will also vary depending on the time of day. Premium rates may apply for
                                late-night or early-morning services (between [Specify Time Range, e.g., 10 PM to 6
                                AM]).
                            </li>

                            <li>
                                > Customers can avoid extra pickup and drop charges by collecting or returning the
                                vehicle directly at the Dura Cabs Services office during official business hours.
                            </li>
                        @else
                            <li>> This fare dose not include inter-state tax , toll , parking please pay directly to the
                                authorities.</li>
                            <li>> For night time driving (between 10:00 Pm to 6:00 Am)on any of the night , there will
                                be
                                a night allowance Rs.250 for the driver.</li>
                        @endif

                    </ul>

                    <h1 class="font-semibold text-lg">Cancel & Refund Policy</h1>
                    <p class="text-sm">The Services are provided by Dura Cabs Services (hereinafter referred to as
                        "Dura" or "Duracabs"), located at Uttar Pradesh Agra 282001. Please read these terms carefully.
                        By using our services, you are agreeing to all terms & conditions set forth. In this agreement,
                        the words "including" and "include" mean "including, but not limited to."
                    </p>







                </div>

            </div>
            <hr class="h-7 mt-5 bg-sky-500 border-0 dark:bg-gray-700" />

        </div>

        <div class="justify-center flex-1 max-w-6xl  mx-auto mt-5  ">
            <a href="/products"
                class="w-full text-center mr-4 px-4 py-2 text-blue-500 border border-blue-500 rounded-md md:w-auto hover:text-white hover:bg-blue-600 dark:border-gray-700 dark:hover:bg-gray-700 dark:text-gray-300">
                Go back shopping
            </a>
            <a href="/my-orders"
                class="w-full text-center px-4 py-2 bg-blue-500 rounded-md text-gray-50 md:w-auto dark:text-gray-300 hover:bg-blue-600 dark:hover:bg-gray-700 dark:bg-gray-800">
                View My Orders
            </a>
        </div>



    </section>

</div>
